import type { CognitoAuthResult, CognitoClientConfig, ForgotPasswordResult, SignUpResult } from "./types";
export declare const createCognitoClient: (config: CognitoClientConfig) => {
    confirmForgotPassword: (email: string, confirmationCode: string, newPassword: string) => Promise<void>;
    loginWithPassword: (email: string, password: string) => Promise<CognitoAuthResult>;
    refreshWithToken: (refreshToken: string) => Promise<CognitoAuthResult>;
    registerWithPassword: (email: string, password: string, fullName: string) => Promise<SignUpResult>;
    requestForgotPassword: (email: string) => Promise<ForgotPasswordResult>;
    updateUserAttributes: (accessToken: string, attributes: Array<{
        name: string;
        value: string;
    }>) => Promise<void>;
    revokeRefreshToken: (refreshToken: string) => Promise<void>;
};
//# sourceMappingURL=client.d.ts.map