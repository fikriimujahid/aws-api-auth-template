"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createCognitoClient = void 0;
const auth_1 = require("./auth");
const errors_1 = require("./errors");
const http_1 = require("./http");
const COGNITO_TARGETS = {
    confirmForgotPassword: "AWSCognitoIdentityProviderService.ConfirmForgotPassword",
    forgotPassword: "AWSCognitoIdentityProviderService.ForgotPassword",
    initiateAuth: "AWSCognitoIdentityProviderService.InitiateAuth",
    updateUserAttributes: "AWSCognitoIdentityProviderService.UpdateUserAttributes",
    revokeToken: "AWSCognitoIdentityProviderService.RevokeToken",
    signUp: "AWSCognitoIdentityProviderService.SignUp"
};
const normalizeConfig = (config) => {
    return {
        ...config,
        apiEndpoint: String(config.apiEndpoint).trim(),
        userPoolClientId: String(config.userPoolClientId).trim()
    };
};
const createCognitoClient = (config) => {
    const normalizedConfig = normalizeConfig(config);
    const post = (target, payload) => {
        return (0, http_1.postToCognito)(normalizedConfig.apiEndpoint, target, payload, normalizedConfig.fetcher ?? fetch);
    };
    const loginWithPassword = async (email, password) => {
        const result = await post(COGNITO_TARGETS.initiateAuth, {
            AuthFlow: "USER_PASSWORD_AUTH",
            ClientId: normalizedConfig.userPoolClientId,
            AuthParameters: {
                USERNAME: email,
                PASSWORD: password
            }
        });
        const authResult = (0, auth_1.validateAuthResult)(result);
        if (!authResult.refreshToken) {
            throw new errors_1.CognitoOperationError("Login succeeded but refresh token is missing", "MissingRefreshToken", 502);
        }
        return authResult;
    };
    const refreshWithToken = async (refreshToken) => {
        const result = await post(COGNITO_TARGETS.initiateAuth, {
            AuthFlow: "REFRESH_TOKEN_AUTH",
            ClientId: normalizedConfig.userPoolClientId,
            AuthParameters: {
                REFRESH_TOKEN: refreshToken
            }
        });
        return (0, auth_1.validateAuthResult)(result);
    };
    const revokeRefreshToken = async (refreshToken) => {
        await post(COGNITO_TARGETS.revokeToken, {
            ClientId: normalizedConfig.userPoolClientId,
            Token: refreshToken
        });
    };
    const registerWithPassword = async (email, password, fullName) => {
        const result = await post(COGNITO_TARGETS.signUp, {
            ClientId: normalizedConfig.userPoolClientId,
            Username: email,
            Password: password,
            UserAttributes: [
                {
                    Name: "email",
                    Value: email
                },
                {
                    Name: "name",
                    Value: fullName
                }
            ]
        });
        return (0, auth_1.mapSignUpResult)(result);
    };
    const requestForgotPassword = async (email) => {
        const result = await post(COGNITO_TARGETS.forgotPassword, {
            ClientId: normalizedConfig.userPoolClientId,
            Username: email
        });
        return (0, auth_1.mapForgotPasswordResult)(result);
    };
    const updateUserAttributes = async (accessToken, attributes) => {
        await post(COGNITO_TARGETS.updateUserAttributes, {
            AccessToken: accessToken,
            UserAttributes: attributes.map((attribute) => ({
                Name: attribute.name,
                Value: attribute.value
            }))
        });
    };
    const confirmForgotPassword = async (email, confirmationCode, newPassword) => {
        await post(COGNITO_TARGETS.confirmForgotPassword, {
            ClientId: normalizedConfig.userPoolClientId,
            Username: email,
            ConfirmationCode: confirmationCode,
            Password: newPassword
        });
    };
    return {
        confirmForgotPassword,
        loginWithPassword,
        refreshWithToken,
        registerWithPassword,
        requestForgotPassword,
        updateUserAttributes,
        revokeRefreshToken
    };
};
exports.createCognitoClient = createCognitoClient;
//# sourceMappingURL=client.js.map