"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.mapForgotPasswordResult = exports.mapSignUpResult = exports.validateAuthResult = void 0;
const errors_1 = require("./errors");
const mapCodeDeliveryDetails = (value) => {
    if (!value) {
        return null;
    }
    return {
        attributeName: value.AttributeName,
        deliveryMedium: value.DeliveryMedium,
        destination: value.Destination
    };
};
const validateAuthResult = (result) => {
    if (result.ChallengeName) {
        throw new errors_1.CognitoOperationError("Account requires additional challenge. This flow is not supported yet.", "ChallengeRequired", 400);
    }
    const accessToken = result.AuthenticationResult?.AccessToken;
    const idToken = result.AuthenticationResult?.IdToken;
    if (!accessToken || !idToken) {
        throw new errors_1.CognitoOperationError("Authentication response is missing token data", "InvalidAuthResponse", 502);
    }
    return {
        accessToken,
        idToken,
        refreshToken: result.AuthenticationResult?.RefreshToken,
        expiresIn: result.AuthenticationResult?.ExpiresIn,
        tokenType: result.AuthenticationResult?.TokenType
    };
};
exports.validateAuthResult = validateAuthResult;
const mapSignUpResult = (result) => {
    return {
        userConfirmed: Boolean(result.UserConfirmed),
        codeDeliveryDetails: mapCodeDeliveryDetails(result.CodeDeliveryDetails)
    };
};
exports.mapSignUpResult = mapSignUpResult;
const mapForgotPasswordResult = (result) => {
    return {
        codeDeliveryDetails: mapCodeDeliveryDetails(result.CodeDeliveryDetails)
    };
};
exports.mapForgotPasswordResult = mapForgotPasswordResult;
//# sourceMappingURL=auth.js.map