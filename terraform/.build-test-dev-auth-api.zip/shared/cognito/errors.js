"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.mapCognitoErrorToHttp = exports.CognitoOperationError = void 0;
class CognitoOperationError extends Error {
    code;
    statusCode;
    constructor(message, code = "InternalError", statusCode = 500) {
        super(message);
        this.code = code;
        this.statusCode = statusCode;
    }
}
exports.CognitoOperationError = CognitoOperationError;
const mapCognitoErrorToHttp = (payload) => {
    const errorCode = typeof payload.__type === "string" ? payload.__type.split("#").pop() ?? "CognitoError" : "CognitoError";
    const message = payload.message || "Cognito request failed";
    switch (errorCode) {
        case "NotAuthorizedException":
        case "UserNotFoundException":
            return new CognitoOperationError(message, errorCode, 401);
        case "UserNotConfirmedException":
            return new CognitoOperationError(message, errorCode, 403);
        case "UsernameExistsException":
            return new CognitoOperationError(message, errorCode, 409);
        case "InvalidParameterException":
        case "InvalidPasswordException":
            return new CognitoOperationError(message, errorCode, 400);
        case "TooManyRequestsException":
            return new CognitoOperationError(message, errorCode, 429);
        default:
            return new CognitoOperationError(message, errorCode, 502);
    }
};
exports.mapCognitoErrorToHttp = mapCognitoErrorToHttp;
//# sourceMappingURL=errors.js.map