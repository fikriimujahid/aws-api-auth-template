"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getAuthUserFromIdToken = exports.parseJwtPayload = void 0;
const decodeBase64Url = (value) => {
    const normalized = value.replace(/-/g, "+").replace(/_/g, "/");
    const padded = normalized.padEnd(Math.ceil(normalized.length / 4) * 4, "=");
    return Buffer.from(padded, "base64").toString("utf8");
};
const parseJwtPayload = (token) => {
    try {
        const parts = token.split(".");
        if (parts.length < 2) {
            return null;
        }
        const payloadJson = decodeBase64Url(parts[1]);
        return JSON.parse(payloadJson);
    }
    catch {
        return null;
    }
};
exports.parseJwtPayload = parseJwtPayload;
const getAuthUserFromIdToken = (idToken) => {
    const payload = (0, exports.parseJwtPayload)(idToken);
    if (!payload) {
        return null;
    }
    const id = payload.sub ?? payload["cognito:username"] ?? "";
    const email = payload.email ?? "";
    const name = payload.name ?? payload.email ?? "Pengguna";
    if (!id || !email) {
        return null;
    }
    return {
        id,
        email,
        name,
        lastCheckinDate: payload["custom:last_checkin_date"]
    };
};
exports.getAuthUserFromIdToken = getAuthUserFromIdToken;
//# sourceMappingURL=tokens.js.map