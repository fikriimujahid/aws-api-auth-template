"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.postToCognito = exports.normalizeEndpoint = exports.mapCognitoErrorToHttp = exports.CognitoOperationError = exports.validateAuthResult = void 0;
var auth_1 = require("./auth");
Object.defineProperty(exports, "validateAuthResult", { enumerable: true, get: function () { return auth_1.validateAuthResult; } });
var errors_1 = require("./errors");
Object.defineProperty(exports, "CognitoOperationError", { enumerable: true, get: function () { return errors_1.CognitoOperationError; } });
Object.defineProperty(exports, "mapCognitoErrorToHttp", { enumerable: true, get: function () { return errors_1.mapCognitoErrorToHttp; } });
var http_1 = require("./http");
Object.defineProperty(exports, "normalizeEndpoint", { enumerable: true, get: function () { return http_1.normalizeEndpoint; } });
Object.defineProperty(exports, "postToCognito", { enumerable: true, get: function () { return http_1.postToCognito; } });
//# sourceMappingURL=core.js.map