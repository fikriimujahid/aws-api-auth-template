import type { AuthUser, JwtPayload } from "./types";
export type { AuthUser, JwtPayload } from "./types";
export declare const parseJwtPayload: (token: string) => JwtPayload | null;
export declare const getAuthUserFromIdToken: (idToken: string) => AuthUser | null;
//# sourceMappingURL=tokens.d.ts.map