import type { CognitoErrorPayload } from "./types";
export declare class CognitoOperationError extends Error {
    readonly code: string;
    readonly statusCode: number;
    constructor(message: string, code?: string, statusCode?: number);
}
export declare const mapCognitoErrorToHttp: (payload: CognitoErrorPayload) => CognitoOperationError;
//# sourceMappingURL=errors.d.ts.map