import type { CognitoAuthResult, CognitoForgotPasswordSuccess, CognitoInitiateAuthSuccess, CognitoSignUpSuccess, ForgotPasswordResult, SignUpResult } from "./types";
export declare const validateAuthResult: (result: CognitoInitiateAuthSuccess) => CognitoAuthResult;
export declare const mapSignUpResult: (result: CognitoSignUpSuccess) => SignUpResult;
export declare const mapForgotPasswordResult: (result: CognitoForgotPasswordSuccess) => ForgotPasswordResult;
//# sourceMappingURL=auth.d.ts.map