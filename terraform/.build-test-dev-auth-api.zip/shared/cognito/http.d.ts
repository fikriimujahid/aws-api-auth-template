export declare const normalizeEndpoint: (endpoint: string) => string;
export declare const postToCognito: <TResponse>(endpoint: string, target: string, payload: Record<string, unknown>, fetcher?: typeof fetch) => Promise<TResponse>;
//# sourceMappingURL=http.d.ts.map