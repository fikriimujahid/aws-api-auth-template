"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.postToCognito = exports.normalizeEndpoint = void 0;
const errors_1 = require("./errors");
const normalizeEndpoint = (endpoint) => {
    if (endpoint.endsWith("/")) {
        return endpoint;
    }
    return `${endpoint}/`;
};
exports.normalizeEndpoint = normalizeEndpoint;
const postToCognito = async (endpoint, target, payload, fetcher = fetch) => {
    const response = await fetcher((0, exports.normalizeEndpoint)(endpoint), {
        method: "POST",
        headers: {
            "content-type": "application/x-amz-json-1.1",
            "x-amz-target": target
        },
        body: JSON.stringify(payload)
    });
    const data = (await response.json().catch(() => ({})));
    if (!response.ok) {
        throw (0, errors_1.mapCognitoErrorToHttp)(data);
    }
    return data;
};
exports.postToCognito = postToCognito;
//# sourceMappingURL=http.js.map