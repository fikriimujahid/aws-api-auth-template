export declare const bearerAuthScheme: {
    readonly type: "http";
    readonly scheme: "bearer";
    readonly bearerFormat: "JWT";
};
export declare const withBearerAuth: (security?: Array<Record<string, string[]>>) => Array<Record<string, string[]>>;
//# sourceMappingURL=auth.d.ts.map