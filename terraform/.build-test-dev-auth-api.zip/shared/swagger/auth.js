"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.withBearerAuth = exports.bearerAuthScheme = void 0;
exports.bearerAuthScheme = {
    type: "http",
    scheme: "bearer",
    bearerFormat: "JWT"
};
const withBearerAuth = (security = []) => {
    return [{ bearerAuth: [] }, ...security];
};
exports.withBearerAuth = withBearerAuth;
//# sourceMappingURL=auth.js.map