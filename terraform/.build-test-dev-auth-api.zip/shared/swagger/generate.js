"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateOpenApiJson = exports.buildOpenApiDocument = void 0;
const openapi_1 = require("./openapi");
const auth_1 = require("./auth");
const normalizePathPrefix = (pathPrefix) => {
    if (pathPrefix === "/") {
        return "/";
    }
    return pathPrefix.replace(/\/$/, "");
};
const stripPathPrefix = (pathName, pathPrefix) => {
    const normalizedPrefix = normalizePathPrefix(pathPrefix);
    if (normalizedPrefix === "/") {
        return pathName;
    }
    if (pathName !== normalizedPrefix && !pathName.startsWith(`${normalizedPrefix}/`)) {
        throw new Error(`OpenAPI path \`${pathName}\` must start with \`${normalizedPrefix}\`.`);
    }
    const strippedPath = pathName.slice(normalizedPrefix.length);
    return strippedPath || "/";
};
const normalizePaths = (paths, pathPrefixToStrip) => {
    if (!pathPrefixToStrip) {
        return paths;
    }
    const normalizedPaths = {};
    for (const [pathName, pathItem] of Object.entries(paths)) {
        const normalizedPath = stripPathPrefix(pathName, pathPrefixToStrip);
        if (normalizedPath in normalizedPaths) {
            throw new Error(`Duplicate OpenAPI path detected after stripping prefix: \`${normalizedPath}\`.`);
        }
        normalizedPaths[normalizedPath] = pathItem;
    }
    return normalizedPaths;
};
const buildOpenApiDocument = (options) => {
    const document = (0, openapi_1.createOpenApiDocument)({
        title: options.title,
        version: options.version,
        description: options.description
    }, normalizePaths(options.paths, options.pathPrefixToStrip));
    const components = {};
    if (options.schemas) {
        components.schemas = options.schemas;
    }
    if (options.includeBearerAuth) {
        components.securitySchemes = { bearerAuth: auth_1.bearerAuthScheme };
    }
    if (Object.keys(components).length > 0) {
        document.components = components;
    }
    if (options.tags && options.tags.length > 0) {
        document.tags = options.tags;
    }
    if (options.servers && options.servers.length > 0) {
        document.servers = options.servers;
    }
    return document;
};
exports.buildOpenApiDocument = buildOpenApiDocument;
const generateOpenApiJson = (document) => {
    return JSON.stringify(document, null, 2);
};
exports.generateOpenApiJson = generateOpenApiJson;
//# sourceMappingURL=generate.js.map