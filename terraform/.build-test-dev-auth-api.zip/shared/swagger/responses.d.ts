import { OpenApiResponseObject, OpenApiSchemaObject } from "./openapi";
export declare const successEnvelopeSchema: (dataSchema: OpenApiSchemaObject) => OpenApiSchemaObject;
export declare const createOkResponse: (schema: OpenApiSchemaObject) => OpenApiResponseObject;
export declare const createCreatedResponse: (schema: OpenApiSchemaObject) => OpenApiResponseObject;
export declare const createNoContentResponse: () => OpenApiResponseObject;
//# sourceMappingURL=responses.d.ts.map