"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createOpenApiDocument = void 0;
const createOpenApiDocument = (info, paths) => ({
    openapi: "3.0.3",
    info,
    paths
});
exports.createOpenApiDocument = createOpenApiDocument;
//# sourceMappingURL=openapi.js.map