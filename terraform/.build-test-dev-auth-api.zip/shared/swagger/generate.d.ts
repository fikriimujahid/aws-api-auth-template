import { OpenApiDocument, OpenApiPathItem } from "./openapi";
export interface BuildOpenApiOptions {
    title: string;
    version: string;
    description?: string;
    paths: Record<string, OpenApiPathItem>;
    pathPrefixToStrip?: string;
    servers?: OpenApiDocument["servers"];
    includeBearerAuth?: boolean;
    schemas?: Record<string, unknown>;
    tags?: Array<{
        name: string;
        description?: string;
    }>;
}
export declare const buildOpenApiDocument: (options: BuildOpenApiOptions) => OpenApiDocument;
export declare const generateOpenApiJson: (document: OpenApiDocument) => string;
//# sourceMappingURL=generate.d.ts.map