import { OpenApiResponseObject, OpenApiSchemaObject } from "./openapi";
export declare const errorEnvelopeSchema: OpenApiSchemaObject;
export declare const createErrorResponse: (description: string) => OpenApiResponseObject;
export declare const commonErrorResponses: {
    "400": OpenApiResponseObject;
    "401": OpenApiResponseObject;
    "403": OpenApiResponseObject;
    "404": OpenApiResponseObject;
    "409": OpenApiResponseObject;
    "429": OpenApiResponseObject;
    "500": OpenApiResponseObject;
};
//# sourceMappingURL=errors.d.ts.map