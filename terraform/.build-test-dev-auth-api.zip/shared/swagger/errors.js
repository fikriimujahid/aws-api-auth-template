"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.commonErrorResponses = exports.createErrorResponse = exports.errorEnvelopeSchema = void 0;
exports.errorEnvelopeSchema = {
    type: "object",
    required: ["success", "error", "meta"],
    properties: {
        success: { type: "boolean", enum: [false] },
        error: {
            type: "object",
            required: ["message"],
            properties: {
                message: { type: "string" },
                code: { type: "string" }
            }
        },
        meta: {
            type: "object",
            required: ["timestamp"],
            properties: {
                requestId: { type: "string" },
                timestamp: { type: "string", format: "date-time" }
            }
        }
    }
};
const createErrorResponse = (description) => ({
    description,
    content: {
        "application/json": {
            schema: exports.errorEnvelopeSchema
        }
    }
});
exports.createErrorResponse = createErrorResponse;
exports.commonErrorResponses = {
    "400": (0, exports.createErrorResponse)("Bad Request"),
    "401": (0, exports.createErrorResponse)("Unauthorized"),
    "403": (0, exports.createErrorResponse)("Forbidden"),
    "404": (0, exports.createErrorResponse)("Not Found"),
    "409": (0, exports.createErrorResponse)("Conflict"),
    "429": (0, exports.createErrorResponse)("Too Many Requests"),
    "500": (0, exports.createErrorResponse)("Internal Server Error")
};
//# sourceMappingURL=errors.js.map