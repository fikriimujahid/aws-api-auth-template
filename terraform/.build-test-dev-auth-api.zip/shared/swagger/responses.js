"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createNoContentResponse = exports.createCreatedResponse = exports.createOkResponse = exports.successEnvelopeSchema = void 0;
const jsonResponse = (description, schema) => ({
    description,
    content: {
        "application/json": {
            schema
        }
    }
});
const successEnvelopeSchema = (dataSchema) => ({
    type: "object",
    required: ["success", "data", "meta"],
    properties: {
        success: { type: "boolean", enum: [true] },
        data: dataSchema,
        meta: {
            type: "object",
            required: ["timestamp"],
            properties: {
                requestId: { type: "string" },
                timestamp: { type: "string", format: "date-time" }
            }
        }
    }
});
exports.successEnvelopeSchema = successEnvelopeSchema;
const createOkResponse = (schema) => jsonResponse("OK", (0, exports.successEnvelopeSchema)(schema));
exports.createOkResponse = createOkResponse;
const createCreatedResponse = (schema) => jsonResponse("Created", (0, exports.successEnvelopeSchema)(schema));
exports.createCreatedResponse = createCreatedResponse;
const createNoContentResponse = () => ({
    description: "No Content"
});
exports.createNoContentResponse = createNoContentResponse;
//# sourceMappingURL=responses.js.map