"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.redactLogContext = exports.createLogger = void 0;
const MAX_LOG_STRING_LENGTH = 2000;
const MAX_LOG_DEPTH = 5;
const SENSITIVE_KEYS = new Set([
    "authorization",
    "cookie",
    "setcookie",
    "password",
    "token",
    "accesstoken",
    "idtoken",
    "refreshtoken",
    "serverkey",
    "secret",
    "signature",
    "signaturekey"
]);
const normalizeKey = (value) => value.toLowerCase().replace(/[^a-z0-9]/g, "");
const isSensitiveKey = (key) => SENSITIVE_KEYS.has(normalizeKey(key));
const truncateString = (value) => {
    if (value.length <= MAX_LOG_STRING_LENGTH) {
        return value;
    }
    return `${value.slice(0, MAX_LOG_STRING_LENGTH)}...<truncated>`;
};
const serializeError = (error) => {
    const serialized = {
        name: error.name,
        message: error.message
    };
    if (typeof error.stack === "string" && error.stack.trim()) {
        serialized.stack = truncateString(error.stack);
    }
    const candidate = error;
    if (candidate.code !== undefined) {
        serialized.code = candidate.code;
    }
    if (candidate.statusCode !== undefined) {
        serialized.statusCode = candidate.statusCode;
    }
    return serialized;
};
const sanitizeLogValue = (value, depth) => {
    if (depth >= MAX_LOG_DEPTH) {
        return "[MaxDepthExceeded]";
    }
    if (value === null || value === undefined) {
        return value;
    }
    if (typeof value === "string") {
        return truncateString(value);
    }
    if (typeof value === "number" || typeof value === "boolean") {
        return value;
    }
    if (typeof value === "bigint") {
        return value.toString();
    }
    if (value instanceof Error) {
        return serializeError(value);
    }
    if (Array.isArray(value)) {
        return value.map((item) => sanitizeLogValue(item, depth + 1));
    }
    if (typeof value === "object") {
        const sanitized = {};
        for (const [key, entryValue] of Object.entries(value)) {
            sanitized[key] = isSensitiveKey(key)
                ? "[REDACTED]"
                : sanitizeLogValue(entryValue, depth + 1);
        }
        return sanitized;
    }
    return String(value);
};
const writeLog = (level, service, event, context = {}) => {
    const payload = {
        timestamp: new Date().toISOString(),
        level,
        service,
        event,
        ...sanitizeLogValue(context, 0)
    };
    const serialized = JSON.stringify(payload);
    if (level === "error") {
        console.error(serialized);
        return;
    }
    if (level === "warn") {
        console.warn(serialized);
        return;
    }
    console.info(serialized);
};
const createLogger = (service) => ({
    info: (event, context) => writeLog("info", service, event, context),
    warn: (event, context) => writeLog("warn", service, event, context),
    error: (event, context) => writeLog("error", service, event, context)
});
exports.createLogger = createLogger;
const redactLogContext = (context) => {
    return sanitizeLogValue(context, 0) ?? {};
};
exports.redactLogContext = redactLogContext;
//# sourceMappingURL=logger.js.map