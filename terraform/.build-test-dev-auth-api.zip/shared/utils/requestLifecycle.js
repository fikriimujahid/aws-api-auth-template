"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.logRequestResult = exports.logRequestReceived = exports.extractErrorCodeFromResponse = void 0;
const extractErrorCodeFromResponse = (response) => {
    if (!response.body) {
        return undefined;
    }
    try {
        const payload = JSON.parse(response.body);
        if (payload.success === false && typeof payload.error?.code === "string") {
            return payload.error.code;
        }
    }
    catch {
        return undefined;
    }
    return undefined;
};
exports.extractErrorCodeFromResponse = extractErrorCodeFromResponse;
const logRequestReceived = (logger, context) => {
    logger.info("request.received", context);
};
exports.logRequestReceived = logRequestReceived;
const logRequestResult = (logger, context, response) => {
    const statusCode = response.statusCode ?? 200;
    const logContext = {
        ...context,
        statusCode
    };
    if (statusCode >= 400) {
        logger.error("request.failed", {
            ...logContext,
            errorCode: (0, exports.extractErrorCodeFromResponse)(response)
        });
        return response;
    }
    logger.info("request.succeeded", logContext);
    return response;
};
exports.logRequestResult = logRequestResult;
//# sourceMappingURL=requestLifecycle.js.map