"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateEnv = exports.parseBooleanEnv = exports.parseNumberEnv = exports.defineEnvSchema = void 0;
const defineEnvSchema = (schema) => schema;
exports.defineEnvSchema = defineEnvSchema;
const parseNumberEnv = (rawValue, key) => {
    const value = Number(rawValue);
    if (!Number.isFinite(value)) {
        throw new Error(`Environment variable ${key} must be a valid number`);
    }
    return value;
};
exports.parseNumberEnv = parseNumberEnv;
const parseBooleanEnv = (rawValue, key) => {
    const normalized = rawValue.trim().toLowerCase();
    if (normalized === "true") {
        return true;
    }
    if (normalized === "false") {
        return false;
    }
    throw new Error(`Environment variable ${key} must be either 'true' or 'false'`);
};
exports.parseBooleanEnv = parseBooleanEnv;
const validateEnv = (source, schema) => {
    const result = {};
    for (const [key, definition] of Object.entries(schema)) {
        const rawValue = source[key];
        const hasValue = typeof rawValue === "string" && rawValue.trim().length > 0;
        if (!hasValue) {
            if (definition.defaultValue !== undefined) {
                result[key] = definition.defaultValue;
                continue;
            }
            if (definition.required) {
                throw new Error(`Missing required environment variable: ${key}`);
            }
            result[key] = undefined;
            continue;
        }
        const parsedValue = definition.parse
            ? definition.parse(rawValue, key)
            : rawValue;
        result[key] = parsedValue;
    }
    return result;
};
exports.validateEnv = validateEnv;
//# sourceMappingURL=env.js.map