export type LogLevel = "info" | "warn" | "error";
export interface LoggerContext {
    [key: string]: unknown;
}
export interface Logger {
    info: (event: string, context?: LoggerContext) => void;
    warn: (event: string, context?: LoggerContext) => void;
    error: (event: string, context?: LoggerContext) => void;
}
export declare const createLogger: (service: string) => Logger;
export declare const redactLogContext: (context: LoggerContext) => LoggerContext;
//# sourceMappingURL=logger.d.ts.map