"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.optionsResponse = exports.createErrorResponse = exports.createSuccessResponse = exports.jsonResponse = exports.buildCorsHeaders = void 0;
const resolveAllowOrigin = (event, allowedOrigin) => {
    if (allowedOrigin && allowedOrigin.trim()) {
        return allowedOrigin.trim();
    }
    const requestOrigin = event.headers.origin ?? event.headers.Origin;
    if (requestOrigin && requestOrigin.trim()) {
        return requestOrigin;
    }
    return "*";
};
const buildResponseMeta = (event) => ({
    requestId: event.requestContext?.requestId,
    timestamp: new Date().toISOString()
});
const sanitizeErrorMessage = (statusCode, message, exposeMessage) => {
    if (statusCode >= 500 && !exposeMessage) {
        return "Internal server error";
    }
    return message;
};
const buildCorsHeaders = (event, options = {}) => {
    const allowOrigin = resolveAllowOrigin(event, options.allowedOrigin);
    const headers = {
        "content-type": "application/json",
        "cache-control": "no-store",
        pragma: "no-cache",
        "x-content-type-options": "nosniff",
        "x-frame-options": "DENY",
        "referrer-policy": "no-referrer",
        "access-control-allow-origin": allowOrigin,
        "access-control-allow-headers": options.allowedHeaders ?? "content-type,authorization",
        "access-control-allow-methods": options.allowedMethods ?? "OPTIONS,GET,POST"
    };
    if (allowOrigin !== "*") {
        headers["access-control-allow-credentials"] = "true";
        headers.vary = "Origin";
    }
    return headers;
};
exports.buildCorsHeaders = buildCorsHeaders;
const jsonResponse = (event, statusCode, body, options = {}) => {
    const response = {
        statusCode,
        headers: (0, exports.buildCorsHeaders)(event, options.cors),
        body: JSON.stringify(body)
    };
    if (options.cookies && options.cookies.length > 0) {
        response.cookies = options.cookies;
    }
    return response;
};
exports.jsonResponse = jsonResponse;
const createSuccessResponse = (event, statusCode, body, options = {}) => {
    const payload = {
        success: true,
        data: body,
        meta: buildResponseMeta(event)
    };
    return (0, exports.jsonResponse)(event, statusCode, payload, options);
};
exports.createSuccessResponse = createSuccessResponse;
const createErrorResponse = (event, statusCode, message, options = {}) => {
    const { code, exposeMessage = false, ...responseOptions } = options;
    const body = {
        success: false,
        error: {
            message: sanitizeErrorMessage(statusCode, message, exposeMessage),
            ...(code ? { code } : {})
        },
        meta: buildResponseMeta(event)
    };
    return (0, exports.jsonResponse)(event, statusCode, body, responseOptions);
};
exports.createErrorResponse = createErrorResponse;
const optionsResponse = (event, options = {}) => {
    const response = {
        statusCode: 204,
        headers: (0, exports.buildCorsHeaders)(event, options.cors),
        body: ""
    };
    if (options.cookies && options.cookies.length > 0) {
        response.cookies = options.cookies;
    }
    return response;
};
exports.optionsResponse = optionsResponse;
//# sourceMappingURL=response.js.map