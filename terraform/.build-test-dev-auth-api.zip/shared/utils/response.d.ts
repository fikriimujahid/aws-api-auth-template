export interface CorsOptions {
    allowedOrigin?: string;
    allowedHeaders?: string;
    allowedMethods?: string;
}
export interface HttpEventLike {
    headers: Record<string, string | undefined>;
    requestContext?: {
        requestId?: string;
    };
}
export interface HttpStructuredResponse {
    statusCode: number;
    headers?: Record<string, string>;
    body: string;
    cookies?: string[];
}
export interface JsonResponseOptions {
    cookies?: string[];
    cors?: CorsOptions;
}
export interface ErrorResponseOptions extends JsonResponseOptions {
    code?: string;
    exposeMessage?: boolean;
}
export interface ResponseMeta {
    requestId?: string;
    timestamp: string;
}
export interface SuccessEnvelope<T> {
    success: true;
    data: T;
    meta: ResponseMeta;
}
export interface ErrorEnvelope {
    success: false;
    error: {
        message: string;
        code?: string;
    };
    meta: ResponseMeta;
}
export declare const buildCorsHeaders: (event: HttpEventLike, options?: CorsOptions) => Record<string, string>;
export declare const jsonResponse: (event: HttpEventLike, statusCode: number, body: unknown, options?: JsonResponseOptions) => HttpStructuredResponse;
export declare const createSuccessResponse: (event: HttpEventLike, statusCode: number, body: unknown, options?: JsonResponseOptions) => HttpStructuredResponse;
export declare const createErrorResponse: (event: HttpEventLike, statusCode: number, message: string, options?: ErrorResponseOptions) => HttpStructuredResponse;
export declare const optionsResponse: (event: HttpEventLike, options?: JsonResponseOptions) => HttpStructuredResponse;
//# sourceMappingURL=response.d.ts.map