export type EnvParser<TValue> = (rawValue: string, key: string) => TValue;
export interface EnvSchemaEntry<TValue> {
    required?: boolean;
    defaultValue?: TValue;
    parse?: EnvParser<TValue>;
}
export type EnvSchema = Record<string, EnvSchemaEntry<unknown>>;
export type InferEnv<TSchema extends EnvSchema> = {
    [K in keyof TSchema]: TSchema[K] extends EnvSchemaEntry<infer TValue> ? TValue : never;
};
export declare const defineEnvSchema: <TSchema extends EnvSchema>(schema: TSchema) => TSchema;
export declare const parseNumberEnv: (rawValue: string, key: string) => number;
export declare const parseBooleanEnv: (rawValue: string, key: string) => boolean;
export declare const validateEnv: <TSchema extends EnvSchema>(source: NodeJS.ProcessEnv, schema: TSchema) => InferEnv<TSchema>;
//# sourceMappingURL=env.d.ts.map