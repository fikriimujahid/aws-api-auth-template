import { APIGatewayProxyEventV2 } from "aws-lambda";
export interface AuthenticatedUser {
    id: string;
    email: string;
    name: string;
}
export declare const getAuthenticatedUserId: (event: APIGatewayProxyEventV2) => string | undefined;
export declare const getAuthenticatedUser: (event: APIGatewayProxyEventV2) => AuthenticatedUser | null;
//# sourceMappingURL=auth.d.ts.map