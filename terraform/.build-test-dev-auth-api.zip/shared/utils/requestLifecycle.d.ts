import { Logger, LoggerContext } from "./logger";
export interface RequestLifecycleContext extends LoggerContext {
    requestId?: string;
    routeKey?: string;
    method?: string;
}
export interface ResponseLike {
    statusCode?: number;
    body?: string;
}
export declare const extractErrorCodeFromResponse: (response: ResponseLike) => string | undefined;
export declare const logRequestReceived: (logger: Logger, context: RequestLifecycleContext) => void;
export declare const logRequestResult: <TResponse extends ResponseLike>(logger: Logger, context: RequestLifecycleContext, response: TResponse) => TResponse;
//# sourceMappingURL=requestLifecycle.d.ts.map