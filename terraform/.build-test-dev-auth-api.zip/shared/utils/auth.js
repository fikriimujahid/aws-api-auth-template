"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getAuthenticatedUser = exports.getAuthenticatedUserId = void 0;
const getJwtClaims = (event) => {
    return event.requestContext.authorizer?.jwt
        ?.claims;
};
const getAuthenticatedUserId = (event) => {
    const claims = getJwtClaims(event);
    return claims?.sub ?? claims?.["cognito:username"];
};
exports.getAuthenticatedUserId = getAuthenticatedUserId;
const getAuthenticatedUser = (event) => {
    const claims = getJwtClaims(event);
    const userId = claims?.sub ?? claims?.["cognito:username"];
    if (!userId) {
        return null;
    }
    return {
        id: userId,
        email: claims?.email ?? "",
        name: claims?.name ?? ""
    };
};
exports.getAuthenticatedUser = getAuthenticatedUser;
//# sourceMappingURL=auth.js.map