import { APIGatewayProxyEventV2 } from "aws-lambda";
export declare const extractCookieValue: (event: APIGatewayProxyEventV2, key: string) => string | null;
export declare const extractRefreshToken: (event: APIGatewayProxyEventV2) => string | null;
export declare const buildRefreshCookie: (refreshToken: string) => string;
export declare const buildClearRefreshCookie: () => string;
//# sourceMappingURL=cookies.d.ts.map