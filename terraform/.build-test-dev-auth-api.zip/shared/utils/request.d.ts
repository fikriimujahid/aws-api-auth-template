import { APIGatewayProxyEventV2 } from "aws-lambda";
export declare const parseEventBody: (event: APIGatewayProxyEventV2) => Record<string, unknown>;
//# sourceMappingURL=request.d.ts.map