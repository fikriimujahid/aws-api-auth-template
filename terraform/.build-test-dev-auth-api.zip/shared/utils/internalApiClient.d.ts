export interface InternalApiErrorPayload {
    message: string;
    code?: string;
}
export declare class InternalApiClientError extends Error {
    readonly statusCode: number;
    readonly code?: string;
    constructor(message: string, statusCode: number, code?: string);
}
export interface InternalApiClientOptions {
    baseUrl: string;
    apiKey: string;
    timeoutMs?: number;
}
export interface InternalApiRequestOptions {
    headers?: Record<string, string>;
    query?: Record<string, string>;
}
export declare const createInternalApiClient: (options: InternalApiClientOptions) => {
    get: <T>(path: string, requestOptions?: InternalApiRequestOptions) => Promise<T>;
};
//# sourceMappingURL=internalApiClient.d.ts.map