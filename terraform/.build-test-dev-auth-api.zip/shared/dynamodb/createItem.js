"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createItem = void 0;
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const createItem = async (client, input) => {
    await client.send(new lib_dynamodb_1.PutCommand(input));
    return input.Item;
};
exports.createItem = createItem;
//# sourceMappingURL=createItem.js.map