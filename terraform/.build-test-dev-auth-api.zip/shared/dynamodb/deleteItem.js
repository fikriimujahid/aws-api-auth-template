"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteItem = void 0;
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const deleteItem = async (client, input) => {
    const response = await client.send(new lib_dynamodb_1.DeleteCommand({
        ...input,
        ReturnValues: input.ReturnValues ?? "ALL_OLD"
    }));
    return response.Attributes;
};
exports.deleteItem = deleteItem;
//# sourceMappingURL=deleteItem.js.map