"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateItem = void 0;
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const updateItem = async (client, input) => {
    const response = await client.send(new lib_dynamodb_1.UpdateCommand({
        ...input,
        ReturnValues: input.ReturnValues ?? "ALL_NEW"
    }));
    return response.Attributes;
};
exports.updateItem = updateItem;
//# sourceMappingURL=updateItem.js.map