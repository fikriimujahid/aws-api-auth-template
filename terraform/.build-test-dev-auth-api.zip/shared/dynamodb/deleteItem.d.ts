import { DeleteCommandInput, DynamoDBDocumentClient } from "@aws-sdk/lib-dynamodb";
export type DeleteItemInput = Omit<DeleteCommandInput, "ReturnValues"> & {
    ReturnValues?: DeleteCommandInput["ReturnValues"];
};
export declare const deleteItem: <TResult extends Record<string, unknown>>(client: DynamoDBDocumentClient, input: DeleteItemInput) => Promise<TResult | undefined>;
//# sourceMappingURL=deleteItem.d.ts.map