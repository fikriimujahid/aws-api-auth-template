import { DynamoDBDocumentClient } from "@aws-sdk/lib-dynamodb";
import { ScanItemsResult } from "./scanItems";
export interface SelectItemsOptions {
    from: string;
    select?: string[];
    keyWhere?: Record<string, unknown>;
    keyBeginsWith?: Record<string, string>;
    where?: Record<string, SelectItemsWhereValue>;
}
export interface SelectItemsWhereOperator {
    eq?: unknown;
    lt?: unknown;
    lte?: unknown;
    gt?: unknown;
    gte?: unknown;
}
export type SelectItemsWhereValue = unknown | SelectItemsWhereOperator;
export declare const selectItems: <TItem extends Record<string, unknown>>(client: DynamoDBDocumentClient, options: SelectItemsOptions) => Promise<ScanItemsResult<TItem>>;
//# sourceMappingURL=selectItems.d.ts.map