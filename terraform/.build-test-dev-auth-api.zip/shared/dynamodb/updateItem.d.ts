import { DynamoDBDocumentClient, UpdateCommandInput } from "@aws-sdk/lib-dynamodb";
export type UpdateItemInput = Omit<UpdateCommandInput, "ReturnValues"> & {
    ReturnValues?: UpdateCommandInput["ReturnValues"];
};
export declare const updateItem: <TResult extends Record<string, unknown>>(client: DynamoDBDocumentClient, input: UpdateItemInput) => Promise<TResult | undefined>;
//# sourceMappingURL=updateItem.d.ts.map