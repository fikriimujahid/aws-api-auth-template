import { DynamoDBDocumentClient, QueryCommandInput } from "@aws-sdk/lib-dynamodb";
export interface QueryItemsResult<TItem extends Record<string, unknown>> {
    items: TItem[];
    count: number;
    lastEvaluatedKey?: Record<string, unknown>;
}
export declare const queryItems: <TItem extends Record<string, unknown>>(client: DynamoDBDocumentClient, input: QueryCommandInput) => Promise<QueryItemsResult<TItem>>;
//# sourceMappingURL=queryItems.d.ts.map