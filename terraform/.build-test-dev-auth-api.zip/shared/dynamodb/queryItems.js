"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.queryItems = void 0;
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const queryItems = async (client, input) => {
    const response = await client.send(new lib_dynamodb_1.QueryCommand(input));
    return {
        items: (response.Items ?? []),
        count: response.Count ?? 0,
        lastEvaluatedKey: response.LastEvaluatedKey
    };
};
exports.queryItems = queryItems;
//# sourceMappingURL=queryItems.js.map