import { DynamoDBDocumentClient, GetCommandInput, QueryCommandInput, ScanCommandInput } from "@aws-sdk/lib-dynamodb";
import { CreateItemInput } from "./createItem";
import { DeleteItemInput } from "./deleteItem";
import { QueryItemsResult } from "./queryItems";
import { ScanItemsResult } from "./scanItems";
import { UpdateItemInput } from "./updateItem";
export declare abstract class BaseRepository<TItem extends Record<string, unknown>, TKey extends Record<string, unknown>> {
    protected readonly tableName: string;
    protected readonly client: DynamoDBDocumentClient;
    constructor(tableName: string, client: DynamoDBDocumentClient);
    create(item: TItem, input?: Omit<CreateItemInput<TItem>, "TableName" | "Item">): Promise<TItem>;
    update(input: Omit<UpdateItemInput, "TableName">): Promise<TItem | undefined>;
    delete(key: TKey, input?: Omit<DeleteItemInput, "TableName" | "Key">): Promise<TItem | undefined>;
    get(key: TKey, input?: Omit<GetCommandInput, "TableName" | "Key">): Promise<TItem | undefined>;
    query(input: Omit<QueryCommandInput, "TableName">): Promise<QueryItemsResult<TItem>>;
    scan(input?: Omit<ScanCommandInput, "TableName">): Promise<ScanItemsResult<TItem>>;
}
//# sourceMappingURL=baseRepository.d.ts.map