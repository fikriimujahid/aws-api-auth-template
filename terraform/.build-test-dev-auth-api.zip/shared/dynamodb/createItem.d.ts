import { DynamoDBDocumentClient, PutCommandInput } from "@aws-sdk/lib-dynamodb";
export interface CreateItemInput<TItem extends Record<string, unknown>> extends Omit<PutCommandInput, "Item"> {
    Item: TItem;
}
export declare const createItem: <TItem extends Record<string, unknown>>(client: DynamoDBDocumentClient, input: CreateItemInput<TItem>) => Promise<TItem>;
//# sourceMappingURL=createItem.d.ts.map