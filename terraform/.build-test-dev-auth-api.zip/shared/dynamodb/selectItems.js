"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.selectItems = void 0;
const queryAllItems_1 = require("./queryAllItems");
const scanItems_1 = require("./scanItems");
const FILTER_OPERATOR_MAP = {
    eq: "=",
    lt: "<",
    lte: "<=",
    gt: ">",
    gte: ">="
};
const isFilterOperator = (value) => {
    if (value === null || Array.isArray(value) || typeof value !== "object") {
        return false;
    }
    const keys = Object.keys(value);
    return keys.length > 0
        && keys.every((key) => key in FILTER_OPERATOR_MAP);
};
const buildProjectionExpression = (columns, attributeNames) => {
    if (columns.length === 0) {
        return undefined;
    }
    return columns
        .map((column, index) => {
        const token = `#select${index}`;
        attributeNames[token] = column;
        return token;
    })
        .join(", ");
};
const buildFilterExpression = (filters, attributeNames, attributeValues) => {
    const entries = Object.entries(filters);
    if (entries.length === 0) {
        return undefined;
    }
    return entries
        .flatMap(([column, value], index) => {
        const nameToken = `#where${index}`;
        attributeNames[nameToken] = column;
        if (isFilterOperator(value)) {
            return Object.entries(value).map(([operator, operatorValue]) => {
                const valueToken = `:where${index}${operator}`;
                attributeValues[valueToken] = operatorValue;
                return `${nameToken} ${FILTER_OPERATOR_MAP[operator]} ${valueToken}`;
            });
        }
        const valueToken = `:where${index}`;
        attributeValues[valueToken] = value;
        return `${nameToken} = ${valueToken}`;
    })
        .join(" AND ");
};
const buildKeyConditionExpression = (filters, prefixFilters, attributeNames, attributeValues) => {
    const equalityEntries = Object.entries(filters);
    const prefixEntries = Object.entries(prefixFilters);
    if (equalityEntries.length === 0 && prefixEntries.length === 0) {
        return undefined;
    }
    const equalityExpressions = equalityEntries.map(([column, value], index) => {
        const nameToken = `#key${index}`;
        const valueToken = `:key${index}`;
        attributeNames[nameToken] = column;
        attributeValues[valueToken] = value;
        return `${nameToken} = ${valueToken}`;
    });
    const prefixExpressions = prefixEntries.map(([column, value], index) => {
        const nameToken = `#keyPrefix${index}`;
        const valueToken = `:keyPrefix${index}`;
        attributeNames[nameToken] = column;
        attributeValues[valueToken] = value;
        return `begins_with(${nameToken}, ${valueToken})`;
    });
    return [...equalityExpressions, ...prefixExpressions].join(" AND ");
};
const selectItems = async (client, options) => {
    const attributeNames = {};
    const attributeValues = {};
    const projectionExpression = buildProjectionExpression(options.select ?? [], attributeNames);
    const keyConditionExpression = buildKeyConditionExpression(options.keyWhere ?? {}, options.keyBeginsWith ?? {}, attributeNames, attributeValues);
    const filterExpression = buildFilterExpression(options.where ?? {}, attributeNames, attributeValues);
    if (keyConditionExpression) {
        const items = await (0, queryAllItems_1.queryAllItems)(client, {
            TableName: options.from,
            ProjectionExpression: projectionExpression,
            KeyConditionExpression: keyConditionExpression,
            FilterExpression: filterExpression,
            ExpressionAttributeNames: attributeNames,
            ExpressionAttributeValues: attributeValues
        });
        return {
            items,
            count: items.length
        };
    }
    return (0, scanItems_1.scanItems)(client, {
        TableName: options.from,
        ProjectionExpression: projectionExpression,
        FilterExpression: filterExpression,
        ExpressionAttributeNames: Object.keys(attributeNames).length > 0 ? attributeNames : undefined,
        ExpressionAttributeValues: Object.keys(attributeValues).length > 0 ? attributeValues : undefined
    });
};
exports.selectItems = selectItems;
//# sourceMappingURL=selectItems.js.map