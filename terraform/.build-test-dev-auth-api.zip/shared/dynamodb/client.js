"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createDynamoDocumentClient = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const defaultTranslateConfig = {
    marshallOptions: {
        removeUndefinedValues: true,
        convertClassInstanceToMap: true
    }
};
const createDynamoDocumentClient = (clientConfig = {}, translateConfig = defaultTranslateConfig) => {
    const client = new client_dynamodb_1.DynamoDBClient(clientConfig);
    return lib_dynamodb_1.DynamoDBDocumentClient.from(client, translateConfig);
};
exports.createDynamoDocumentClient = createDynamoDocumentClient;
//# sourceMappingURL=client.js.map