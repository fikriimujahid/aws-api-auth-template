import { DynamoDBDocumentClient, ScanCommandInput } from "@aws-sdk/lib-dynamodb";
export interface ScanItemsResult<TItem extends Record<string, unknown>> {
    items: TItem[];
    count: number;
    lastEvaluatedKey?: Record<string, unknown>;
}
export declare const scanItems: <TItem extends Record<string, unknown>>(client: DynamoDBDocumentClient, input: ScanCommandInput) => Promise<ScanItemsResult<TItem>>;
//# sourceMappingURL=scanItems.d.ts.map