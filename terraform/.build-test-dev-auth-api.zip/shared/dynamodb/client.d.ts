import { DynamoDBClientConfig } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, TranslateConfig } from "@aws-sdk/lib-dynamodb";
export declare const createDynamoDocumentClient: (clientConfig?: DynamoDBClientConfig, translateConfig?: TranslateConfig) => DynamoDBDocumentClient;
//# sourceMappingURL=client.d.ts.map