import { DynamoDBDocumentClient, QueryCommandInput } from "@aws-sdk/lib-dynamodb";
export declare const queryAllItems: <TItem extends Record<string, unknown>>(client: DynamoDBDocumentClient, input: QueryCommandInput) => Promise<TItem[]>;
//# sourceMappingURL=queryAllItems.d.ts.map