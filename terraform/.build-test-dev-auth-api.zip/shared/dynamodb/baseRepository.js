"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BaseRepository = void 0;
const createItem_1 = require("./createItem");
const deleteItem_1 = require("./deleteItem");
const getItem_1 = require("./getItem");
const queryItems_1 = require("./queryItems");
const scanItems_1 = require("./scanItems");
const updateItem_1 = require("./updateItem");
class BaseRepository {
    tableName;
    client;
    constructor(tableName, client) {
        this.tableName = tableName;
        this.client = client;
    }
    create(item, input = {}) {
        return (0, createItem_1.createItem)(this.client, {
            ...input,
            TableName: this.tableName,
            Item: item
        });
    }
    update(input) {
        return (0, updateItem_1.updateItem)(this.client, {
            ...input,
            TableName: this.tableName
        });
    }
    delete(key, input = {}) {
        return (0, deleteItem_1.deleteItem)(this.client, {
            ...input,
            TableName: this.tableName,
            Key: key
        });
    }
    get(key, input = {}) {
        return (0, getItem_1.getItem)(this.client, {
            ...input,
            TableName: this.tableName,
            Key: key
        });
    }
    query(input) {
        return (0, queryItems_1.queryItems)(this.client, {
            ...input,
            TableName: this.tableName
        });
    }
    scan(input = {}) {
        return (0, scanItems_1.scanItems)(this.client, {
            ...input,
            TableName: this.tableName
        });
    }
}
exports.BaseRepository = BaseRepository;
//# sourceMappingURL=baseRepository.js.map