"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getItem = void 0;
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const getItem = async (client, input) => {
    const response = await client.send(new lib_dynamodb_1.GetCommand(input));
    return response.Item;
};
exports.getItem = getItem;
//# sourceMappingURL=getItem.js.map