"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.queryAllItems = void 0;
const queryItems_1 = require("./queryItems");
const queryAllItems = async (client, input) => {
    const items = [];
    let lastEvaluatedKey;
    do {
        const response = await (0, queryItems_1.queryItems)(client, {
            ...input,
            ExclusiveStartKey: lastEvaluatedKey
        });
        items.push(...response.items);
        lastEvaluatedKey = response.lastEvaluatedKey;
    } while (lastEvaluatedKey);
    return items;
};
exports.queryAllItems = queryAllItems;
//# sourceMappingURL=queryAllItems.js.map