"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.scanItems = void 0;
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const scanItems = async (client, input) => {
    const response = await client.send(new lib_dynamodb_1.ScanCommand(input));
    return {
        items: (response.Items ?? []),
        count: response.Count ?? 0,
        lastEvaluatedKey: response.LastEvaluatedKey
    };
};
exports.scanItems = scanItems;
//# sourceMappingURL=scanItems.js.map