import { DynamoDBDocumentClient, GetCommandInput } from "@aws-sdk/lib-dynamodb";
export declare const getItem: <TResult extends Record<string, unknown>>(client: DynamoDBDocumentClient, input: GetCommandInput) => Promise<TResult | undefined>;
//# sourceMappingURL=getItem.d.ts.map