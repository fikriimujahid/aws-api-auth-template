export declare const ROUTES: {
    readonly LOGIN: {
        readonly method: "POST";
        readonly path: "/api/auth/login";
        readonly routeKey: "POST /api/auth/login";
    };
    readonly REGISTER: {
        readonly method: "POST";
        readonly path: "/api/auth/register";
        readonly routeKey: "POST /api/auth/register";
    };
    readonly FORGOT_PASSWORD: {
        readonly method: "POST";
        readonly path: "/api/auth/forgot-password";
        readonly routeKey: "POST /api/auth/forgot-password";
    };
    readonly CONFIRM_FORGOT_PASSWORD: {
        readonly method: "POST";
        readonly path: "/api/auth/forgot-password/confirm";
        readonly routeKey: "POST /api/auth/forgot-password/confirm";
    };
    readonly REFRESH: {
        readonly method: "POST";
        readonly path: "/api/auth/refresh";
        readonly routeKey: "POST /api/auth/refresh";
    };
    readonly LOGOUT: {
        readonly method: "POST";
        readonly path: "/api/auth/logout";
        readonly routeKey: "POST /api/auth/logout";
    };
    readonly SESSION: {
        readonly method: "GET";
        readonly path: "/api/auth/session";
        readonly routeKey: "GET /api/auth/session";
    };
};
//# sourceMappingURL=routes.d.ts.map