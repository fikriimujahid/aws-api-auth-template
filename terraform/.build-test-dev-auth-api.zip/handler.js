"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.main = exports.handler = void 0;
const logger_1 = require("./shared/utils/logger.js");
const requestLifecycle_1 = require("./shared/utils/requestLifecycle.js");
const response_1 = require("./shared/utils/response.js");
const env_1 = require("./config/env");
const confirmForgotPasswordHandler_1 = require("./handlers/confirmForgotPasswordHandler");
const forgotPasswordHandler_1 = require("./handlers/forgotPasswordHandler");
const loginHandler_1 = require("./handlers/loginHandler");
const logoutHandler_1 = require("./handlers/logoutHandler");
const refreshHandler_1 = require("./handlers/refreshHandler");
const registerHandler_1 = require("./handlers/registerHandler");
const sessionHandler_1 = require("./handlers/sessionHandler");
const routes_1 = require("./routes");
(0, env_1.getAuthServiceEnv)();
const logger = (0, logger_1.createLogger)("auth-service");
const routeHandlers = {
    [routes_1.ROUTES.LOGIN.routeKey]: loginHandler_1.loginHandler,
    [routes_1.ROUTES.FORGOT_PASSWORD.routeKey]: forgotPasswordHandler_1.forgotPasswordHandler,
    [routes_1.ROUTES.CONFIRM_FORGOT_PASSWORD.routeKey]: confirmForgotPasswordHandler_1.confirmForgotPasswordHandler,
    [routes_1.ROUTES.REGISTER.routeKey]: registerHandler_1.registerHandler,
    [routes_1.ROUTES.REFRESH.routeKey]: refreshHandler_1.refreshHandler,
    [routes_1.ROUTES.LOGOUT.routeKey]: logoutHandler_1.logoutHandler,
    [routes_1.ROUTES.SESSION.routeKey]: sessionHandler_1.sessionHandler
};
const handler = async (event) => {
    const requestContext = {
        requestId: event.requestContext?.requestId,
        routeKey: event.routeKey,
        method: event.requestContext.http.method
    };
    (0, requestLifecycle_1.logRequestReceived)(logger, requestContext);
    if (event.requestContext.http.method === "OPTIONS") {
        return (0, requestLifecycle_1.logRequestResult)(logger, requestContext, (0, response_1.optionsResponse)(event));
    }
    const routeHandler = routeHandlers[event.routeKey ?? ""];
    if (routeHandler) {
        return (0, requestLifecycle_1.logRequestResult)(logger, requestContext, await routeHandler(event));
    }
    return (0, requestLifecycle_1.logRequestResult)(logger, requestContext, (0, response_1.createErrorResponse)(event, 404, "Route not found", { code: "ROUTE_NOT_FOUND" }));
};
exports.handler = handler;
exports.main = exports.handler;
//# sourceMappingURL=handler.js.map