"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.mapAuthErrorToResponse = void 0;
const core_1 = require("../shared/cognito/core.js");
const response_1 = require("../shared/utils/response.js");
const applicationErrors_1 = require("./applicationErrors");
const mapAuthErrorToResponse = (event, error, fallback) => {
    if (error instanceof applicationErrors_1.InvalidIdTokenError) {
        return (0, response_1.createErrorResponse)(event, 502, error.message, {
            code: "INVALID_ID_TOKEN"
        });
    }
    if (error instanceof core_1.CognitoOperationError) {
        return (0, response_1.createErrorResponse)(event, error.statusCode, error.message, {
            code: error.code
        });
    }
    return (0, response_1.createErrorResponse)(event, fallback.statusCode, fallback.message, {
        code: fallback.code
    });
};
exports.mapAuthErrorToResponse = mapAuthErrorToResponse;
//# sourceMappingURL=errorToResponse.js.map