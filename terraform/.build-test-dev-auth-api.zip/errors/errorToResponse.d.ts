import { APIGatewayProxyEventV2, APIGatewayProxyStructuredResultV2 } from "aws-lambda";
export interface AuthErrorFallback {
    statusCode: number;
    message: string;
    code: string;
}
export declare const mapAuthErrorToResponse: (event: APIGatewayProxyEventV2, error: unknown, fallback: AuthErrorFallback) => APIGatewayProxyStructuredResultV2;
//# sourceMappingURL=errorToResponse.d.ts.map