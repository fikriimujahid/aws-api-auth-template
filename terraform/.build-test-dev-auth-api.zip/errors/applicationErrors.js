"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.InvalidIdTokenError = void 0;
class InvalidIdTokenError extends Error {
    constructor() {
        super("Invalid ID token in refresh response");
        this.name = "InvalidIdTokenError";
    }
}
exports.InvalidIdTokenError = InvalidIdTokenError;
//# sourceMappingURL=applicationErrors.js.map