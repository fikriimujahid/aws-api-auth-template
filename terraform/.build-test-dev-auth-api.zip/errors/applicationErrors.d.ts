export declare class InvalidIdTokenError extends Error {
    constructor();
}
//# sourceMappingURL=applicationErrors.d.ts.map