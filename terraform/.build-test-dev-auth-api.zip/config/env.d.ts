import { InferEnv } from "../shared/utils/env.js";
declare const authEnvSchema: {
    COGNITO_API_ENDPOINT: {
        required: true;
    };
    COGNITO_USER_POOL_CLIENT_ID: {
        required: true;
    };
    AUTH_ALLOWED_ORIGIN: {
        defaultValue: string;
    };
    AUTH_COOKIE_DOMAIN: {
        defaultValue: string;
    };
    AUTH_COOKIE_SECURE: {
        defaultValue: boolean;
        parse: (rawValue: string, key: string) => boolean;
    };
    AUTH_COOKIE_SAME_SITE: {
        defaultValue: string;
    };
    AUTH_REFRESH_COOKIE_NAME: {
        defaultValue: string;
    };
    AUTH_REFRESH_COOKIE_PATH: {
        defaultValue: string;
    };
    AUTH_REFRESH_COOKIE_MAX_AGE_SECONDS: {
        defaultValue: number;
        parse: (rawValue: string, key: string) => number;
    };
};
export type AuthServiceEnv = InferEnv<typeof authEnvSchema>;
export declare const getAuthServiceEnv: () => InferEnv<{
    COGNITO_API_ENDPOINT: {
        required: true;
    };
    COGNITO_USER_POOL_CLIENT_ID: {
        required: true;
    };
    AUTH_ALLOWED_ORIGIN: {
        defaultValue: string;
    };
    AUTH_COOKIE_DOMAIN: {
        defaultValue: string;
    };
    AUTH_COOKIE_SECURE: {
        defaultValue: boolean;
        parse: (rawValue: string, key: string) => boolean;
    };
    AUTH_COOKIE_SAME_SITE: {
        defaultValue: string;
    };
    AUTH_REFRESH_COOKIE_NAME: {
        defaultValue: string;
    };
    AUTH_REFRESH_COOKIE_PATH: {
        defaultValue: string;
    };
    AUTH_REFRESH_COOKIE_MAX_AGE_SECONDS: {
        defaultValue: number;
        parse: (rawValue: string, key: string) => number;
    };
}>;
export {};
//# sourceMappingURL=env.d.ts.map