"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getAuthServiceEnv = void 0;
const env_1 = require("../shared/utils/env.js");
const authEnvSchema = (0, env_1.defineEnvSchema)({
    COGNITO_API_ENDPOINT: { required: true },
    COGNITO_USER_POOL_CLIENT_ID: { required: true },
    AUTH_ALLOWED_ORIGIN: { defaultValue: "" },
    AUTH_COOKIE_DOMAIN: { defaultValue: "" },
    AUTH_COOKIE_SECURE: { defaultValue: true, parse: env_1.parseBooleanEnv },
    AUTH_COOKIE_SAME_SITE: { defaultValue: "Lax" },
    AUTH_REFRESH_COOKIE_NAME: { defaultValue: "kjl_rt" },
    AUTH_REFRESH_COOKIE_PATH: { defaultValue: "/api/auth" },
    AUTH_REFRESH_COOKIE_MAX_AGE_SECONDS: { defaultValue: 2592000, parse: env_1.parseNumberEnv }
});
let cachedEnv = null;
const getAuthServiceEnv = () => {
    if (!cachedEnv) {
        cachedEnv = (0, env_1.validateEnv)(process.env, authEnvSchema);
    }
    return cachedEnv;
};
exports.getAuthServiceEnv = getAuthServiceEnv;
//# sourceMappingURL=env.js.map