import { APIGatewayProxyEventV2 } from "aws-lambda";
interface LogoutRequest {
    refreshToken: string | null;
}
interface SafeParseSuccess<T> {
    success: true;
    data: T;
}
type SafeParseResult<T> = SafeParseSuccess<T>;
export declare const logoutSchema: {
    safeParse: (input: unknown) => SafeParseResult<LogoutRequest>;
    safeParseEvent: (event: APIGatewayProxyEventV2) => SafeParseResult<LogoutRequest>;
};
export {};
//# sourceMappingURL=logoutSchema.d.ts.map