import { APIGatewayProxyEventV2 } from "aws-lambda";
interface ConfirmForgotPasswordPayload {
    email: string;
    code: string;
    newPassword: string;
}
interface SafeParseSuccess<T> {
    success: true;
    data: T;
}
interface SafeParseFailure {
    success: false;
    error: string;
}
type SafeParseResult<T> = SafeParseSuccess<T> | SafeParseFailure;
export declare const confirmForgotPasswordSchema: {
    safeParse: (input: unknown) => SafeParseResult<ConfirmForgotPasswordPayload>;
    safeParseEvent: (event: APIGatewayProxyEventV2) => SafeParseResult<ConfirmForgotPasswordPayload>;
};
export {};
//# sourceMappingURL=confirmForgotPasswordSchema.d.ts.map