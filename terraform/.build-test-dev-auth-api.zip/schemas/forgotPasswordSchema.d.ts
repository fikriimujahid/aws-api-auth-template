import { APIGatewayProxyEventV2 } from "aws-lambda";
interface ForgotPasswordPayload {
    email: string;
}
interface SafeParseSuccess<T> {
    success: true;
    data: T;
}
interface SafeParseFailure {
    success: false;
    error: string;
}
type SafeParseResult<T> = SafeParseSuccess<T> | SafeParseFailure;
export declare const forgotPasswordSchema: {
    safeParse: (input: unknown) => SafeParseResult<ForgotPasswordPayload>;
    safeParseEvent: (event: APIGatewayProxyEventV2) => SafeParseResult<ForgotPasswordPayload>;
};
export {};
//# sourceMappingURL=forgotPasswordSchema.d.ts.map