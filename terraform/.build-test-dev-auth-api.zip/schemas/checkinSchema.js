"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.checkinSchema = void 0;
const request_1 = require("../shared/utils/request.js");
const isNonEmptyString = (value) => {
    return typeof value === "string" && value.trim().length > 0;
};
const safeParsePayload = (input) => {
    if (!input || typeof input !== "object" || Array.isArray(input)) {
        return {
            success: false,
            error: "Invalid request body"
        };
    }
    const payload = input;
    if (!isNonEmptyString(payload.productId)) {
        return {
            success: false,
            error: "Missing product id"
        };
    }
    if (!isNonEmptyString(payload.topicId)) {
        return {
            success: false,
            error: "Missing topic id"
        };
    }
    if (!isNonEmptyString(payload.sessionId)) {
        return {
            success: false,
            error: "Missing session id"
        };
    }
    return {
        success: true,
        data: {
            productId: payload.productId.trim(),
            topicId: payload.topicId.trim(),
            sessionId: payload.sessionId.trim()
        }
    };
};
exports.checkinSchema = {
    safeParseEvent: (event) => {
        try {
            return safeParsePayload((0, request_1.parseEventBody)(event));
        }
        catch {
            return {
                success: false,
                error: "Invalid JSON body"
            };
        }
    }
};
//# sourceMappingURL=checkinSchema.js.map