import { APIGatewayProxyEventV2 } from "aws-lambda";
interface GetCheckinActivityRequest {
    weekCount: number;
}
interface SafeParseSuccess<T> {
    success: true;
    data: T;
}
interface SafeParseFailure {
    success: false;
    error: string;
}
type SafeParseResult<T> = SafeParseSuccess<T> | SafeParseFailure;
export declare const getCheckinActivitySchema: {
    safeParseEvent: (event: APIGatewayProxyEventV2) => SafeParseResult<GetCheckinActivityRequest>;
};
export {};
//# sourceMappingURL=getCheckinActivitySchema.d.ts.map