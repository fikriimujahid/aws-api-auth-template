"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.sessionSchema = void 0;
const cookies_1 = require("../shared/utils/cookies.js");
const normalizePayloadObject = (input) => {
    if (!input || typeof input !== "object" || Array.isArray(input)) {
        return {};
    }
    return input;
};
const safeParsePayload = (input) => {
    const payload = normalizePayloadObject(input);
    const refreshToken = payload.refreshToken;
    return {
        success: true,
        data: {
            refreshToken: typeof refreshToken === "string" && refreshToken.length > 0 ? refreshToken : null
        }
    };
};
exports.sessionSchema = {
    safeParse: (input) => {
        return safeParsePayload(input);
    },
    safeParseEvent: (event) => {
        return safeParsePayload({ refreshToken: (0, cookies_1.extractRefreshToken)(event) });
    }
};
//# sourceMappingURL=sessionSchema.js.map