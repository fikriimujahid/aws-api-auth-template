"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.registerSchema = void 0;
const request_1 = require("../shared/utils/request.js");
const readFullName = (payload) => {
    const value = payload.fullName;
    const normalizedValue = typeof value === "string" ? value.trim() : "";
    return normalizedValue.length > 0 ? normalizedValue : null;
};
const readEmail = (payload) => {
    const value = payload.email;
    const normalizedValue = typeof value === "string" ? value.trim() : "";
    return normalizedValue.length > 0 ? normalizedValue : null;
};
const readPassword = (payload) => {
    const value = payload.password;
    if (typeof value !== "string") {
        return null;
    }
    return value.length > 0 ? value : null;
};
const normalizePayloadObject = (input) => {
    if (!input || typeof input !== "object" || Array.isArray(input)) {
        return {};
    }
    return input;
};
const safeParsePayload = (input) => {
    const payload = normalizePayloadObject(input);
    const fullName = readFullName(payload);
    const email = readEmail(payload);
    const password = readPassword(payload);
    if (!fullName || !email || !password) {
        return {
            success: false,
            error: "fullName, email, and password are required"
        };
    }
    return {
        success: true,
        data: {
            fullName,
            email,
            password
        }
    };
};
exports.registerSchema = {
    safeParse: (input) => {
        return safeParsePayload(input);
    },
    safeParseEvent: (event) => {
        try {
            return safeParsePayload((0, request_1.parseEventBody)(event));
        }
        catch {
            return {
                success: false,
                error: "Invalid JSON body"
            };
        }
    }
};
//# sourceMappingURL=registerSchema.js.map