import { APIGatewayProxyEventV2 } from "aws-lambda";
interface RegisterPayload {
    fullName: string;
    email: string;
    password: string;
}
interface SafeParseSuccess<T> {
    success: true;
    data: T;
}
interface SafeParseFailure {
    success: false;
    error: string;
}
type SafeParseResult<T> = SafeParseSuccess<T> | SafeParseFailure;
export declare const registerSchema: {
    safeParse: (input: unknown) => SafeParseResult<RegisterPayload>;
    safeParseEvent: (event: APIGatewayProxyEventV2) => SafeParseResult<RegisterPayload>;
};
export {};
//# sourceMappingURL=registerSchema.d.ts.map