import { APIGatewayProxyEventV2 } from "aws-lambda";
interface CheckinRequest {
    productId: string;
    topicId: string;
    sessionId: string;
}
interface SafeParseSuccess<T> {
    success: true;
    data: T;
}
interface SafeParseFailure {
    success: false;
    error: string;
}
type SafeParseResult<T> = SafeParseSuccess<T> | SafeParseFailure;
export declare const checkinSchema: {
    safeParseEvent: (event: APIGatewayProxyEventV2) => SafeParseResult<CheckinRequest>;
};
export {};
//# sourceMappingURL=checkinSchema.d.ts.map