"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.confirmForgotPasswordSchema = void 0;
const request_1 = require("../shared/utils/request.js");
const readEmail = (payload) => {
    const value = payload.email;
    const normalizedValue = typeof value === "string" ? value.trim() : "";
    return normalizedValue.length > 0 ? normalizedValue : null;
};
const readCode = (payload) => {
    const value = payload.code;
    const normalizedValue = typeof value === "string" ? value.trim() : "";
    return normalizedValue.length > 0 ? normalizedValue : null;
};
const readNewPassword = (payload) => {
    const value = payload.newPassword;
    if (typeof value !== "string") {
        return null;
    }
    return value.length > 0 ? value : null;
};
const normalizePayloadObject = (input) => {
    if (!input || typeof input !== "object" || Array.isArray(input)) {
        return {};
    }
    return input;
};
const safeParsePayload = (input) => {
    const payload = normalizePayloadObject(input);
    const email = readEmail(payload);
    const code = readCode(payload);
    const newPassword = readNewPassword(payload);
    if (!email || !code || !newPassword) {
        return {
            success: false,
            error: "email, code, and newPassword are required"
        };
    }
    return {
        success: true,
        data: {
            email,
            code,
            newPassword
        }
    };
};
exports.confirmForgotPasswordSchema = {
    safeParse: (input) => {
        return safeParsePayload(input);
    },
    safeParseEvent: (event) => {
        try {
            return safeParsePayload((0, request_1.parseEventBody)(event));
        }
        catch {
            return {
                success: false,
                error: "Invalid JSON body"
            };
        }
    }
};
//# sourceMappingURL=confirmForgotPasswordSchema.js.map