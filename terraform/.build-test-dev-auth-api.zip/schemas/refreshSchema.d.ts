import { APIGatewayProxyEventV2 } from "aws-lambda";
interface RefreshRequest {
    refreshToken: string;
}
interface SafeParseSuccess<T> {
    success: true;
    data: T;
}
interface SafeParseFailure {
    success: false;
    error: string;
}
type SafeParseResult<T> = SafeParseSuccess<T> | SafeParseFailure;
export declare const refreshSchema: {
    safeParse: (input: unknown) => SafeParseResult<RefreshRequest>;
    safeParseEvent: (event: APIGatewayProxyEventV2) => SafeParseResult<RefreshRequest>;
};
export {};
//# sourceMappingURL=refreshSchema.d.ts.map