import { APIGatewayProxyEventV2 } from "aws-lambda";
interface LoginPayload {
    email: string;
    password: string;
}
interface SafeParseSuccess<T> {
    success: true;
    data: T;
}
interface SafeParseFailure {
    success: false;
    error: string;
}
type SafeParseResult<T> = SafeParseSuccess<T> | SafeParseFailure;
export declare const loginSchema: {
    safeParse: (input: unknown) => SafeParseResult<LoginPayload>;
    safeParseEvent: (event: APIGatewayProxyEventV2) => SafeParseResult<LoginPayload>;
};
export {};
//# sourceMappingURL=loginSchema.d.ts.map