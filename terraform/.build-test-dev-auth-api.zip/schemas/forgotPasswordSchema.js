"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.forgotPasswordSchema = void 0;
const request_1 = require("../shared/utils/request.js");
const readEmail = (payload) => {
    const value = payload.email;
    const normalizedValue = typeof value === "string" ? value.trim() : "";
    return normalizedValue.length > 0 ? normalizedValue : null;
};
const normalizePayloadObject = (input) => {
    if (!input || typeof input !== "object" || Array.isArray(input)) {
        return {};
    }
    return input;
};
const safeParsePayload = (input) => {
    const payload = normalizePayloadObject(input);
    const email = readEmail(payload);
    if (!email) {
        return {
            success: false,
            error: "email is required"
        };
    }
    return {
        success: true,
        data: {
            email
        }
    };
};
exports.forgotPasswordSchema = {
    safeParse: (input) => {
        return safeParsePayload(input);
    },
    safeParseEvent: (event) => {
        try {
            return safeParsePayload((0, request_1.parseEventBody)(event));
        }
        catch {
            return {
                success: false,
                error: "Invalid JSON body"
            };
        }
    }
};
//# sourceMappingURL=forgotPasswordSchema.js.map