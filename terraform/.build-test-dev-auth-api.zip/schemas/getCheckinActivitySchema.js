"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getCheckinActivitySchema = void 0;
const parseWeekCount = (rawValue) => {
    if (!rawValue || rawValue.trim().length === 0) {
        return 3;
    }
    const parsed = Number.parseInt(rawValue, 10);
    if (!Number.isInteger(parsed)) {
        return null;
    }
    if (parsed < 1 || parsed > 12) {
        return null;
    }
    return parsed;
};
exports.getCheckinActivitySchema = {
    safeParseEvent: (event) => {
        const parsedWeekCount = parseWeekCount(event.queryStringParameters?.weekCount);
        if (parsedWeekCount === null) {
            return {
                success: false,
                error: "Invalid weekCount query parameter"
            };
        }
        return {
            success: true,
            data: {
                weekCount: parsedWeekCount
            }
        };
    }
};
//# sourceMappingURL=getCheckinActivitySchema.js.map