import { APIGatewayProxyEventV2 } from "aws-lambda";
interface SessionRequest {
    refreshToken: string | null;
}
interface SafeParseSuccess<T> {
    success: true;
    data: T;
}
type SafeParseResult<T> = SafeParseSuccess<T>;
export declare const sessionSchema: {
    safeParse: (input: unknown) => SafeParseResult<SessionRequest>;
    safeParseEvent: (event: APIGatewayProxyEventV2) => SafeParseResult<SessionRequest>;
};
export {};
//# sourceMappingURL=sessionSchema.d.ts.map