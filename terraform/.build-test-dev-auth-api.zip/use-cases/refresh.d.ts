export interface RefreshInput {
    refreshToken: string;
}
export interface RefreshResult {
    accessToken: string;
    idToken: string;
    expiresIn: number | undefined;
    tokenType: string | undefined;
    user: {
        id: string;
        email: string;
        name: string;
    };
    nextRefreshToken: string;
}
export declare const refresh: (input: RefreshInput) => Promise<RefreshResult>;
//# sourceMappingURL=refresh.d.ts.map