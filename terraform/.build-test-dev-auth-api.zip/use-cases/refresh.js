"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.refresh = void 0;
const tokens_1 = require("../shared/cognito/tokens.js");
const cognito_1 = require("../services/cognito");
const applicationErrors_1 = require("../errors/applicationErrors");
const refresh = async (input) => {
    const authResult = await (0, cognito_1.refreshWithToken)(input.refreshToken);
    const user = (0, tokens_1.getAuthUserFromIdToken)(authResult.idToken);
    if (!user) {
        throw new applicationErrors_1.InvalidIdTokenError();
    }
    return {
        accessToken: authResult.accessToken,
        idToken: authResult.idToken,
        expiresIn: authResult.expiresIn,
        tokenType: authResult.tokenType,
        user,
        nextRefreshToken: authResult.refreshToken ?? input.refreshToken
    };
};
exports.refresh = refresh;
//# sourceMappingURL=refresh.js.map