export interface LogoutInput {
    refreshToken?: string | null;
}
export declare const logout: (input: LogoutInput) => Promise<void>;
//# sourceMappingURL=logout.d.ts.map