"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.session = void 0;
const tokens_1 = require("../shared/cognito/tokens.js");
const cognito_1 = require("../services/cognito");
const session = async (input) => {
    try {
        const authResult = await (0, cognito_1.refreshWithToken)(input.refreshToken);
        const user = (0, tokens_1.getAuthUserFromIdToken)(authResult.idToken);
        if (!user) {
            return {
                authenticated: false,
                clearRefreshCookie: true
            };
        }
        return {
            authenticated: true,
            session: {
                accessToken: authResult.accessToken,
                idToken: authResult.idToken,
                expiresIn: authResult.expiresIn,
                tokenType: authResult.tokenType,
                user
            },
            nextRefreshToken: authResult.refreshToken ?? input.refreshToken
        };
    }
    catch {
        return {
            authenticated: false,
            clearRefreshCookie: true
        };
    }
};
exports.session = session;
//# sourceMappingURL=session.js.map