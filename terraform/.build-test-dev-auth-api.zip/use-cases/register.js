"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.register = void 0;
const cognito_1 = require("../services/cognito");
const register = async (input) => {
    return (0, cognito_1.registerWithPassword)(input.email, input.password, input.fullName);
};
exports.register = register;
//# sourceMappingURL=register.js.map