"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.confirmForgotPassword = void 0;
const cognito_1 = require("../services/cognito");
const confirmForgotPassword = async (input) => {
    await (0, cognito_1.confirmForgotPassword)(input.email, input.code, input.newPassword);
    return {
        passwordResetConfirmed: true
    };
};
exports.confirmForgotPassword = confirmForgotPassword;
//# sourceMappingURL=confirmForgotPassword.js.map