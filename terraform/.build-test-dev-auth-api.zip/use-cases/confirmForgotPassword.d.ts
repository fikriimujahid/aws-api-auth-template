export interface ConfirmForgotPasswordInput {
    email: string;
    code: string;
    newPassword: string;
}
export declare const confirmForgotPassword: (input: ConfirmForgotPasswordInput) => Promise<{
    passwordResetConfirmed: boolean;
}>;
//# sourceMappingURL=confirmForgotPassword.d.ts.map