export interface ForgotPasswordInput {
    email: string;
}
export declare const forgotPassword: (input: ForgotPasswordInput) => Promise<import("../shared/cognito").ForgotPasswordResult>;
//# sourceMappingURL=forgotPassword.d.ts.map