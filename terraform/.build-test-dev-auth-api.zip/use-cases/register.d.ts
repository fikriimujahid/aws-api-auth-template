export interface RegisterInput {
    email: string;
    password: string;
    fullName: string;
}
export declare const register: (input: RegisterInput) => Promise<import("../shared/cognito").SignUpResult>;
//# sourceMappingURL=register.d.ts.map