"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.forgotPassword = void 0;
const cognito_1 = require("../services/cognito");
const forgotPassword = async (input) => {
    return (0, cognito_1.requestForgotPassword)(input.email);
};
exports.forgotPassword = forgotPassword;
//# sourceMappingURL=forgotPassword.js.map