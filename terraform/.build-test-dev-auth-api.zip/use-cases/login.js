"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.login = void 0;
const tokens_1 = require("../shared/cognito/tokens.js");
const cognito_1 = require("../services/cognito");
const login = async (input) => {
    const authResult = await (0, cognito_1.loginWithPassword)(input.email, input.password);
    const user = (0, tokens_1.getAuthUserFromIdToken)(authResult.idToken) ?? {
        id: input.email,
        email: input.email,
        name: input.email.split("@")[0] || "Pengguna"
    };
    return {
        accessToken: authResult.accessToken,
        idToken: authResult.idToken,
        expiresIn: authResult.expiresIn,
        tokenType: authResult.tokenType,
        user,
        refreshToken: authResult.refreshToken ?? ""
    };
};
exports.login = login;
//# sourceMappingURL=login.js.map