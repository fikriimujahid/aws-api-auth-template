export interface SessionInput {
    refreshToken: string;
}
export interface SessionResult {
    authenticated: boolean;
    session?: {
        accessToken: string;
        idToken: string;
        expiresIn: number | undefined;
        tokenType: string | undefined;
        user: {
            id: string;
            email: string;
            name: string;
        };
    };
    nextRefreshToken?: string;
    clearRefreshCookie?: boolean;
}
export declare const session: (input: SessionInput) => Promise<SessionResult>;
//# sourceMappingURL=session.d.ts.map