export interface LoginInput {
    email: string;
    password: string;
}
export interface LoginResult {
    accessToken: string;
    idToken: string;
    expiresIn: number | undefined;
    tokenType: string | undefined;
    user: {
        id: string;
        email: string;
        name: string;
        lastCheckinDate?: string;
    };
    refreshToken: string;
}
export declare const login: (input: LoginInput) => Promise<LoginResult>;
//# sourceMappingURL=login.d.ts.map