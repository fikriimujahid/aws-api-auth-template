"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.logout = void 0;
const cognito_1 = require("../services/cognito");
const logout = async (input) => {
    if (!input.refreshToken) {
        return;
    }
    try {
        await (0, cognito_1.revokeRefreshToken)(input.refreshToken);
    }
    catch {
        // Continue logout flow even when revoke fails to ensure local cookie is removed.
    }
};
exports.logout = logout;
//# sourceMappingURL=logout.js.map