import { OpenApiPathItem } from "../shared/swagger/openapi.js";
export declare const refreshDocPath = "/api/auth/refresh";
export declare const refreshDocPathItem: OpenApiPathItem;
//# sourceMappingURL=refresh.doc.d.ts.map