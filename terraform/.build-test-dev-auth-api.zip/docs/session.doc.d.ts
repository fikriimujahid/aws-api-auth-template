import { OpenApiPathItem } from "../shared/swagger/openapi.js";
export declare const sessionDocPath = "/api/auth/session";
export declare const sessionDocPathItem: OpenApiPathItem;
//# sourceMappingURL=session.doc.d.ts.map