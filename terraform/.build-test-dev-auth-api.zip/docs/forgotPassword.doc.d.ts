import { OpenApiPathItem } from "../shared/swagger/openapi.js";
export declare const forgotPasswordDocPath = "/api/auth/forgot-password";
export declare const forgotPasswordDocPathItem: OpenApiPathItem;
//# sourceMappingURL=forgotPassword.doc.d.ts.map