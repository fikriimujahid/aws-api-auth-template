import { OpenApiPathItem } from "../shared/swagger/openapi.js";
export declare const confirmForgotPasswordDocPath = "/api/auth/forgot-password/confirm";
export declare const confirmForgotPasswordDocPathItem: OpenApiPathItem;
//# sourceMappingURL=confirmForgotPassword.doc.d.ts.map