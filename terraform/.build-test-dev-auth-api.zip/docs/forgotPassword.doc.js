"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.forgotPasswordDocPathItem = exports.forgotPasswordDocPath = void 0;
const errors_1 = require("../shared/swagger/errors.js");
const responses_1 = require("../shared/swagger/responses.js");
const schemas_1 = require("./schemas");
exports.forgotPasswordDocPath = "/api/auth/forgot-password";
exports.forgotPasswordDocPathItem = {
    post: {
        summary: "Request password reset code",
        tags: ["Auth"],
        requestBody: {
            required: true,
            content: {
                "application/json": {
                    schema: {
                        type: "object",
                        required: ["email"],
                        properties: {
                            email: { type: "string", format: "email" }
                        }
                    }
                }
            }
        },
        responses: {
            "200": (0, responses_1.createOkResponse)({
                type: "object",
                required: ["codeDeliveryDetails"],
                properties: {
                    codeDeliveryDetails: {
                        oneOf: [schemas_1.codeDeliveryDetailsSchema, { type: "null" }]
                    }
                }
            }),
            ...errors_1.commonErrorResponses
        }
    }
};
//# sourceMappingURL=forgotPassword.doc.js.map