"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateAuthServiceOpenApiJson = exports.buildAuthServiceOpenApi = exports.authServicePaths = void 0;
const generate_1 = require("../shared/swagger/generate.js");
const confirmForgotPassword_doc_1 = require("./confirmForgotPassword.doc");
const forgotPassword_doc_1 = require("./forgotPassword.doc");
const login_doc_1 = require("./login.doc");
const logout_doc_1 = require("./logout.doc");
const refresh_doc_1 = require("./refresh.doc");
const register_doc_1 = require("./register.doc");
const session_doc_1 = require("./session.doc");
exports.authServicePaths = {
    [login_doc_1.loginDocPath]: login_doc_1.loginDocPathItem,
    [register_doc_1.registerDocPath]: register_doc_1.registerDocPathItem,
    [forgotPassword_doc_1.forgotPasswordDocPath]: forgotPassword_doc_1.forgotPasswordDocPathItem,
    [confirmForgotPassword_doc_1.confirmForgotPasswordDocPath]: confirmForgotPassword_doc_1.confirmForgotPasswordDocPathItem,
    [refresh_doc_1.refreshDocPath]: refresh_doc_1.refreshDocPathItem,
    [logout_doc_1.logoutDocPath]: logout_doc_1.logoutDocPathItem,
    [session_doc_1.sessionDocPath]: session_doc_1.sessionDocPathItem
};
const authServiceLocalBaseUrl = "http://localhost:3004";
const buildAuthServiceOpenApi = () => {
    return (0, generate_1.buildOpenApiDocument)({
        title: "Auth Service API",
        version: "1.0.0",
        description: "Auth endpoints for KeJepangDulu",
        servers: [
            {
                url: "{authServiceBaseUrl}",
                description: "Auth service base URL",
                variables: {
                    authServiceBaseUrl: {
                        default: authServiceLocalBaseUrl,
                        description: "Auth service local base URL"
                    }
                }
            }
        ],
        includeBearerAuth: true,
        tags: [{ name: "Auth", description: "Authentication operations" }],
        paths: exports.authServicePaths
    });
};
exports.buildAuthServiceOpenApi = buildAuthServiceOpenApi;
const generateAuthServiceOpenApiJson = () => {
    return (0, generate_1.generateOpenApiJson)((0, exports.buildAuthServiceOpenApi)());
};
exports.generateAuthServiceOpenApiJson = generateAuthServiceOpenApiJson;
//# sourceMappingURL=index.js.map