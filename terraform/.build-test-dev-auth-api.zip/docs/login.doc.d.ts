import { OpenApiPathItem } from "../shared/swagger/openapi.js";
export declare const loginDocPath = "/api/auth/login";
export declare const loginDocPathItem: OpenApiPathItem;
//# sourceMappingURL=login.doc.d.ts.map