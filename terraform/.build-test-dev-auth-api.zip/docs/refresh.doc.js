"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.refreshDocPathItem = exports.refreshDocPath = void 0;
const errors_1 = require("../shared/swagger/errors.js");
const responses_1 = require("../shared/swagger/responses.js");
const schemas_1 = require("./schemas");
exports.refreshDocPath = "/api/auth/refresh";
exports.refreshDocPathItem = {
    post: {
        summary: "Refresh auth session from refresh token cookie",
        tags: ["Auth"],
        responses: {
            "200": (0, responses_1.createOkResponse)(schemas_1.authSessionSchema),
            ...errors_1.commonErrorResponses
        }
    }
};
//# sourceMappingURL=refresh.doc.js.map