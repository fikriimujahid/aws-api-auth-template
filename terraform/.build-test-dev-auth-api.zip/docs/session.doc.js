"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.sessionDocPathItem = exports.sessionDocPath = void 0;
const responses_1 = require("../shared/swagger/responses.js");
const schemas_1 = require("./schemas");
exports.sessionDocPath = "/api/auth/session";
exports.sessionDocPathItem = {
    get: {
        summary: "Get current authentication session status",
        tags: ["Auth"],
        responses: {
            "200": (0, responses_1.createOkResponse)({
                oneOf: [
                    {
                        type: "object",
                        required: ["authenticated"],
                        properties: {
                            authenticated: { type: "boolean", enum: [false] }
                        }
                    },
                    {
                        type: "object",
                        required: ["authenticated", "session"],
                        properties: {
                            authenticated: { type: "boolean", enum: [true] },
                            session: schemas_1.authSessionSchema
                        }
                    }
                ]
            })
        }
    }
};
//# sourceMappingURL=session.doc.js.map