import { OpenApiPathItem } from "../shared/swagger/openapi.js";
export declare const logoutDocPath = "/api/auth/logout";
export declare const logoutDocPathItem: OpenApiPathItem;
//# sourceMappingURL=logout.doc.d.ts.map