import { OpenApiPathItem } from "../shared/swagger/openapi.js";
export declare const registerDocPath = "/api/auth/register";
export declare const registerDocPathItem: OpenApiPathItem;
//# sourceMappingURL=register.doc.d.ts.map