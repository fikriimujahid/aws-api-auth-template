import { OpenApiPathItem } from "../shared/swagger/openapi.js";
export declare const authServicePaths: Record<string, OpenApiPathItem>;
export declare const buildAuthServiceOpenApi: () => import("../shared/swagger/openapi.js").OpenApiDocument;
export declare const generateAuthServiceOpenApiJson: () => string;
//# sourceMappingURL=index.d.ts.map