import { OpenApiSchemaObject } from "../shared/swagger/openapi.js";
export declare const authUserSchema: OpenApiSchemaObject;
export declare const authSessionSchema: OpenApiSchemaObject;
export declare const codeDeliveryDetailsSchema: OpenApiSchemaObject;
//# sourceMappingURL=schemas.d.ts.map