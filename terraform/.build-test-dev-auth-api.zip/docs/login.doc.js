"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.loginDocPathItem = exports.loginDocPath = void 0;
const errors_1 = require("../shared/swagger/errors.js");
const responses_1 = require("../shared/swagger/responses.js");
const schemas_1 = require("./schemas");
exports.loginDocPath = "/api/auth/login";
exports.loginDocPathItem = {
    post: {
        summary: "Authenticate with email and password",
        tags: ["Auth"],
        requestBody: {
            required: true,
            content: {
                "application/json": {
                    schema: {
                        type: "object",
                        required: ["email", "password"],
                        properties: {
                            email: { type: "string", format: "email" },
                            password: { type: "string" }
                        }
                    }
                }
            }
        },
        responses: {
            "200": (0, responses_1.createOkResponse)(schemas_1.authSessionSchema),
            ...errors_1.commonErrorResponses
        }
    }
};
//# sourceMappingURL=login.doc.js.map