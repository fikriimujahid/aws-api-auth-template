"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.logoutDocPathItem = exports.logoutDocPath = void 0;
const responses_1 = require("../shared/swagger/responses.js");
exports.logoutDocPath = "/api/auth/logout";
exports.logoutDocPathItem = {
    post: {
        summary: "Logout current session and clear refresh cookie",
        tags: ["Auth"],
        responses: {
            "200": (0, responses_1.createOkResponse)({
                type: "object",
                required: ["loggedOut"],
                properties: {
                    loggedOut: { type: "boolean", enum: [true] }
                }
            })
        }
    }
};
//# sourceMappingURL=logout.doc.js.map