"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.codeDeliveryDetailsSchema = exports.authSessionSchema = exports.authUserSchema = void 0;
exports.authUserSchema = {
    type: "object",
    required: ["id", "email", "name"],
    properties: {
        id: { type: "string" },
        email: { type: "string", format: "email" },
        name: { type: "string" }
    }
};
exports.authSessionSchema = {
    type: "object",
    required: ["accessToken", "idToken", "user"],
    properties: {
        accessToken: { type: "string" },
        idToken: { type: "string" },
        expiresIn: { type: "number" },
        tokenType: { type: "string" },
        user: exports.authUserSchema
    }
};
exports.codeDeliveryDetailsSchema = {
    type: "object",
    properties: {
        attributeName: { type: "string" },
        deliveryMedium: { type: "string" },
        destination: { type: "string" }
    }
};
//# sourceMappingURL=schemas.js.map