"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.registerDocPathItem = exports.registerDocPath = void 0;
const errors_1 = require("../shared/swagger/errors.js");
const responses_1 = require("../shared/swagger/responses.js");
const schemas_1 = require("./schemas");
exports.registerDocPath = "/api/auth/register";
exports.registerDocPathItem = {
    post: {
        summary: "Register a new account",
        tags: ["Auth"],
        requestBody: {
            required: true,
            content: {
                "application/json": {
                    schema: {
                        type: "object",
                        required: ["fullName", "email", "password"],
                        properties: {
                            fullName: { type: "string" },
                            email: { type: "string", format: "email" },
                            password: { type: "string" }
                        }
                    }
                }
            }
        },
        responses: {
            "200": (0, responses_1.createOkResponse)({
                type: "object",
                required: ["userConfirmed"],
                properties: {
                    userConfirmed: { type: "boolean" },
                    codeDeliveryDetails: {
                        oneOf: [schemas_1.codeDeliveryDetailsSchema, { type: "null" }]
                    }
                }
            }),
            ...errors_1.commonErrorResponses
        }
    }
};
//# sourceMappingURL=register.doc.js.map