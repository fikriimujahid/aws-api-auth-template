"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.confirmForgotPasswordDocPathItem = exports.confirmForgotPasswordDocPath = void 0;
const errors_1 = require("../shared/swagger/errors.js");
const responses_1 = require("../shared/swagger/responses.js");
exports.confirmForgotPasswordDocPath = "/api/auth/forgot-password/confirm";
exports.confirmForgotPasswordDocPathItem = {
    post: {
        summary: "Confirm password reset with verification code",
        tags: ["Auth"],
        requestBody: {
            required: true,
            content: {
                "application/json": {
                    schema: {
                        type: "object",
                        required: ["email", "code", "newPassword"],
                        properties: {
                            email: { type: "string", format: "email" },
                            code: { type: "string" },
                            newPassword: { type: "string" }
                        }
                    }
                }
            }
        },
        responses: {
            "200": (0, responses_1.createOkResponse)({
                type: "object",
                required: ["passwordResetConfirmed"],
                properties: {
                    passwordResetConfirmed: { type: "boolean", enum: [true] }
                }
            }),
            ...errors_1.commonErrorResponses
        }
    }
};
//# sourceMappingURL=confirmForgotPassword.doc.js.map