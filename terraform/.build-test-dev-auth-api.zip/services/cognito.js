"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateUserLastCheckinDate = exports.confirmForgotPassword = exports.requestForgotPassword = exports.registerWithPassword = exports.revokeRefreshToken = exports.refreshWithToken = exports.loginWithPassword = void 0;
const env_1 = require("../config/env");
const client_1 = require("../shared/cognito/client.js");
const getCognitoConfig = () => {
    const { COGNITO_API_ENDPOINT, COGNITO_USER_POOL_CLIENT_ID } = (0, env_1.getAuthServiceEnv)();
    return {
        apiEndpoint: String(COGNITO_API_ENDPOINT).trim(),
        userPoolClientId: String(COGNITO_USER_POOL_CLIENT_ID).trim()
    };
};
const getCognitoClient = () => (0, client_1.createCognitoClient)(getCognitoConfig());
const loginWithPassword = (email, password) => {
    return getCognitoClient().loginWithPassword(email, password);
};
exports.loginWithPassword = loginWithPassword;
const refreshWithToken = (refreshToken) => {
    return getCognitoClient().refreshWithToken(refreshToken);
};
exports.refreshWithToken = refreshWithToken;
const revokeRefreshToken = (refreshToken) => {
    return getCognitoClient().revokeRefreshToken(refreshToken);
};
exports.revokeRefreshToken = revokeRefreshToken;
const registerWithPassword = (email, password, fullName) => {
    return getCognitoClient().registerWithPassword(email, password, fullName);
};
exports.registerWithPassword = registerWithPassword;
const requestForgotPassword = (email) => {
    return getCognitoClient().requestForgotPassword(email);
};
exports.requestForgotPassword = requestForgotPassword;
const confirmForgotPassword = (email, confirmationCode, newPassword) => {
    return getCognitoClient().confirmForgotPassword(email, confirmationCode, newPassword);
};
exports.confirmForgotPassword = confirmForgotPassword;
const updateUserLastCheckinDate = (accessToken, lastCheckinDate) => {
    return getCognitoClient().updateUserAttributes(accessToken, [
        {
            name: "custom:last_checkin_date",
            value: lastCheckinDate
        }
    ]);
};
exports.updateUserLastCheckinDate = updateUserLastCheckinDate;
//# sourceMappingURL=cognito.js.map