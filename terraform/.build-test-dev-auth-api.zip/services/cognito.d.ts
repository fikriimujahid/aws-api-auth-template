export declare const loginWithPassword: (email: string, password: string) => Promise<import("../shared/cognito").CognitoAuthResult>;
export declare const refreshWithToken: (refreshToken: string) => Promise<import("../shared/cognito").CognitoAuthResult>;
export declare const revokeRefreshToken: (refreshToken: string) => Promise<void>;
export declare const registerWithPassword: (email: string, password: string, fullName: string) => Promise<import("../shared/cognito").SignUpResult>;
export declare const requestForgotPassword: (email: string) => Promise<import("../shared/cognito").ForgotPasswordResult>;
export declare const confirmForgotPassword: (email: string, confirmationCode: string, newPassword: string) => Promise<void>;
export declare const updateUserLastCheckinDate: (accessToken: string, lastCheckinDate: string) => Promise<void>;
//# sourceMappingURL=cognito.d.ts.map