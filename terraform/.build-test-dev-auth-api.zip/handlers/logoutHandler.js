"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.logoutHandler = void 0;
const cookies_1 = require("../shared/utils/cookies.js");
const response_1 = require("../shared/utils/response.js");
const logoutSchema_1 = require("../schemas/logoutSchema");
const logout_1 = require("../use-cases/logout");
const logoutHandler = async (event) => {
    const parsedPayload = logoutSchema_1.logoutSchema.safeParseEvent(event);
    await (0, logout_1.logout)({ refreshToken: parsedPayload.data.refreshToken });
    return (0, response_1.createSuccessResponse)(event, 200, {
        loggedOut: true
    }, {
        cookies: [(0, cookies_1.buildClearRefreshCookie)()]
    });
};
exports.logoutHandler = logoutHandler;
//# sourceMappingURL=logoutHandler.js.map