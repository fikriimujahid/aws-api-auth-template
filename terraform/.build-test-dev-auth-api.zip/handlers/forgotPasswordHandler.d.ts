import { APIGatewayProxyEventV2, APIGatewayProxyStructuredResultV2 } from "aws-lambda";
export declare const forgotPasswordHandler: (event: APIGatewayProxyEventV2) => Promise<APIGatewayProxyStructuredResultV2>;
//# sourceMappingURL=forgotPasswordHandler.d.ts.map