"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.sessionHandler = void 0;
const cookies_1 = require("../shared/utils/cookies.js");
const response_1 = require("../shared/utils/response.js");
const sessionSchema_1 = require("../schemas/sessionSchema");
const session_1 = require("../use-cases/session");
const sessionHandler = async (event) => {
    const parsedPayload = sessionSchema_1.sessionSchema.safeParseEvent(event);
    const refreshToken = parsedPayload.data.refreshToken;
    if (!refreshToken) {
        return (0, response_1.createSuccessResponse)(event, 200, { authenticated: false });
    }
    const result = await (0, session_1.session)({ refreshToken });
    if (result.authenticated && result.session) {
        return (0, response_1.createSuccessResponse)(event, 200, {
            authenticated: true,
            session: result.session
        }, {
            cookies: [(0, cookies_1.buildRefreshCookie)(result.nextRefreshToken ?? refreshToken)]
        });
    }
    if (result.clearRefreshCookie) {
        return (0, response_1.createSuccessResponse)(event, 200, { authenticated: false }, { cookies: [(0, cookies_1.buildClearRefreshCookie)()] });
    }
    return (0, response_1.createSuccessResponse)(event, 200, { authenticated: false });
};
exports.sessionHandler = sessionHandler;
//# sourceMappingURL=sessionHandler.js.map