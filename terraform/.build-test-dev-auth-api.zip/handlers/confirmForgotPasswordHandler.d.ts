import { APIGatewayProxyEventV2, APIGatewayProxyStructuredResultV2 } from "aws-lambda";
export declare const confirmForgotPasswordHandler: (event: APIGatewayProxyEventV2) => Promise<APIGatewayProxyStructuredResultV2>;
//# sourceMappingURL=confirmForgotPasswordHandler.d.ts.map