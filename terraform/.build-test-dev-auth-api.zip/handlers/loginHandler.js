"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.loginHandler = void 0;
const cookies_1 = require("../shared/utils/cookies.js");
const response_1 = require("../shared/utils/response.js");
const errorToResponse_1 = require("../errors/errorToResponse");
const loginSchema_1 = require("../schemas/loginSchema");
const login_1 = require("../use-cases/login");
const loginHandler = async (event) => {
    const parsedPayload = loginSchema_1.loginSchema.safeParseEvent(event);
    if (!parsedPayload.success) {
        return (0, response_1.createErrorResponse)(event, 400, parsedPayload.error, {
            code: parsedPayload.error === "Invalid JSON body" ? "INVALID_JSON" : "VALIDATION_ERROR"
        });
    }
    try {
        const result = await (0, login_1.login)({
            email: parsedPayload.data.email,
            password: parsedPayload.data.password
        });
        return (0, response_1.createSuccessResponse)(event, 200, {
            accessToken: result.accessToken,
            idToken: result.idToken,
            expiresIn: result.expiresIn,
            tokenType: result.tokenType,
            user: result.user
        }, {
            cookies: [(0, cookies_1.buildRefreshCookie)(result.refreshToken)]
        });
    }
    catch (error) {
        return (0, errorToResponse_1.mapAuthErrorToResponse)(event, error, {
            statusCode: 500,
            message: "Login failed",
            code: "LOGIN_FAILED"
        });
    }
};
exports.loginHandler = loginHandler;
//# sourceMappingURL=loginHandler.js.map