import { APIGatewayProxyEventV2, APIGatewayProxyStructuredResultV2 } from "aws-lambda";
export declare const logoutHandler: (event: APIGatewayProxyEventV2) => Promise<APIGatewayProxyStructuredResultV2>;
//# sourceMappingURL=logoutHandler.d.ts.map