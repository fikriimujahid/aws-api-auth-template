"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.registerHandler = void 0;
const response_1 = require("../shared/utils/response.js");
const errorToResponse_1 = require("../errors/errorToResponse");
const registerSchema_1 = require("../schemas/registerSchema");
const register_1 = require("../use-cases/register");
const registerHandler = async (event) => {
    const parsedPayload = registerSchema_1.registerSchema.safeParseEvent(event);
    if (!parsedPayload.success) {
        return (0, response_1.createErrorResponse)(event, 400, parsedPayload.error, {
            code: parsedPayload.error === "Invalid JSON body" ? "INVALID_JSON" : "VALIDATION_ERROR"
        });
    }
    try {
        const result = await (0, register_1.register)({
            email: parsedPayload.data.email,
            password: parsedPayload.data.password,
            fullName: parsedPayload.data.fullName
        });
        return (0, response_1.createSuccessResponse)(event, 200, {
            userConfirmed: result.userConfirmed,
            codeDeliveryDetails: result.codeDeliveryDetails
        });
    }
    catch (error) {
        return (0, errorToResponse_1.mapAuthErrorToResponse)(event, error, {
            statusCode: 500,
            message: "Registration failed",
            code: "REGISTRATION_FAILED"
        });
    }
};
exports.registerHandler = registerHandler;
//# sourceMappingURL=registerHandler.js.map