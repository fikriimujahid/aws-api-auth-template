"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.confirmForgotPasswordHandler = void 0;
const response_1 = require("../shared/utils/response.js");
const errorToResponse_1 = require("../errors/errorToResponse");
const confirmForgotPasswordSchema_1 = require("../schemas/confirmForgotPasswordSchema");
const confirmForgotPassword_1 = require("../use-cases/confirmForgotPassword");
const confirmForgotPasswordHandler = async (event) => {
    const parsedPayload = confirmForgotPasswordSchema_1.confirmForgotPasswordSchema.safeParseEvent(event);
    if (!parsedPayload.success) {
        return (0, response_1.createErrorResponse)(event, 400, parsedPayload.error, {
            code: parsedPayload.error === "Invalid JSON body" ? "INVALID_JSON" : "VALIDATION_ERROR"
        });
    }
    try {
        const result = await (0, confirmForgotPassword_1.confirmForgotPassword)({
            email: parsedPayload.data.email,
            code: parsedPayload.data.code,
            newPassword: parsedPayload.data.newPassword
        });
        return (0, response_1.createSuccessResponse)(event, 200, result);
    }
    catch (error) {
        return (0, errorToResponse_1.mapAuthErrorToResponse)(event, error, {
            statusCode: 500,
            message: "Failed to confirm password reset",
            code: "CONFIRM_PASSWORD_RESET_FAILED"
        });
    }
};
exports.confirmForgotPasswordHandler = confirmForgotPasswordHandler;
//# sourceMappingURL=confirmForgotPasswordHandler.js.map