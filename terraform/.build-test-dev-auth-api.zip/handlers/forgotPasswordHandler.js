"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.forgotPasswordHandler = void 0;
const response_1 = require("../shared/utils/response.js");
const errorToResponse_1 = require("../errors/errorToResponse");
const forgotPasswordSchema_1 = require("../schemas/forgotPasswordSchema");
const forgotPassword_1 = require("../use-cases/forgotPassword");
const forgotPasswordHandler = async (event) => {
    const parsedPayload = forgotPasswordSchema_1.forgotPasswordSchema.safeParseEvent(event);
    if (!parsedPayload.success) {
        return (0, response_1.createErrorResponse)(event, 400, parsedPayload.error, {
            code: parsedPayload.error === "Invalid JSON body" ? "INVALID_JSON" : "VALIDATION_ERROR"
        });
    }
    try {
        const result = await (0, forgotPassword_1.forgotPassword)({ email: parsedPayload.data.email });
        return (0, response_1.createSuccessResponse)(event, 200, {
            codeDeliveryDetails: result.codeDeliveryDetails
        });
    }
    catch (error) {
        return (0, errorToResponse_1.mapAuthErrorToResponse)(event, error, {
            statusCode: 500,
            message: "Failed to request password reset",
            code: "FORGOT_PASSWORD_FAILED"
        });
    }
};
exports.forgotPasswordHandler = forgotPasswordHandler;
//# sourceMappingURL=forgotPasswordHandler.js.map