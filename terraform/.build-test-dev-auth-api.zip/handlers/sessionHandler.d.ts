import { APIGatewayProxyEventV2, APIGatewayProxyStructuredResultV2 } from "aws-lambda";
export declare const sessionHandler: (event: APIGatewayProxyEventV2) => Promise<APIGatewayProxyStructuredResultV2>;
//# sourceMappingURL=sessionHandler.d.ts.map