"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.refreshHandler = void 0;
const cookies_1 = require("../shared/utils/cookies.js");
const response_1 = require("../shared/utils/response.js");
const errorToResponse_1 = require("../errors/errorToResponse");
const refreshSchema_1 = require("../schemas/refreshSchema");
const refresh_1 = require("../use-cases/refresh");
const refreshHandler = async (event) => {
    const parsedPayload = refreshSchema_1.refreshSchema.safeParseEvent(event);
    if (!parsedPayload.success) {
        return (0, response_1.createErrorResponse)(event, 401, parsedPayload.error, {
            code: "REFRESH_TOKEN_NOT_FOUND"
        });
    }
    try {
        const result = await (0, refresh_1.refresh)({ refreshToken: parsedPayload.data.refreshToken });
        return (0, response_1.createSuccessResponse)(event, 200, {
            accessToken: result.accessToken,
            idToken: result.idToken,
            expiresIn: result.expiresIn,
            tokenType: result.tokenType,
            user: result.user
        }, {
            cookies: [(0, cookies_1.buildRefreshCookie)(result.nextRefreshToken)]
        });
    }
    catch (error) {
        return (0, errorToResponse_1.mapAuthErrorToResponse)(event, error, {
            statusCode: 500,
            message: "Failed to refresh session",
            code: "REFRESH_FAILED"
        });
    }
};
exports.refreshHandler = refreshHandler;
//# sourceMappingURL=refreshHandler.js.map